"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/config.ts
  var CONFIG;
  var init_config = __esm({
    "src/config.ts"() {
      "use strict";
      CONFIG = {
        // The backend API endpoint
        API_BASE: "https://api.scholic.com/api",
        // The frontend web application URL (for profile links and login)
        WEB_URL: "https://scholic.com"
      };
    }
  });

  // src/background.ts
  var require_background = __commonJS({
    "src/background.ts"() {
      init_config();
      var API_BASE = CONFIG.API_BASE;
      chrome.webRequest.onHeadersReceived.addListener(
        async (details) => {
          if (details.type !== "main_frame") return;
          const url = details.url;
          if (url.includes("viewer.html?url=")) return;
          const contentTypeHeader = details.responseHeaders?.find(
            (h) => h.name.toLowerCase() === "content-type"
          );
          const contentType = contentTypeHeader?.value?.toLowerCase() || "";
          const isPdf = contentType.includes("application/pdf") || contentType.includes("application/octet-stream") && url.toLowerCase().endsWith(".pdf");
          if (!isPdf) return;
          try {
            const domain = new URL(url).hostname;
            const result = await chrome.storage.local.get("enabledDomains");
            const enabledDomains = result.enabledDomains || {};
            if (!enabledDomains[domain]) return;
          } catch {
            return;
          }
          const viewerUrl = chrome.runtime.getURL(`viewer.html?url=${encodeURIComponent(url)}`);
          chrome.tabs.update(details.tabId, { url: viewerUrl });
        },
        { urls: ["<all_urls>"] },
        ["responseHeaders"]
      );
      chrome.action.onClicked.addListener(async (tab) => {
        if (!tab.id || !tab.url) return;
        try {
          const url = new URL(tab.url);
          if (url.protocol.startsWith("chrome") || url.protocol.startsWith("about")) return;
          const domain = url.hostname;
          const result = await chrome.storage.local.get("enabledDomains");
          const enabledDomains = result.enabledDomains || {};
          const isEnabled = !enabledDomains[domain];
          enabledDomains[domain] = isEnabled;
          await chrome.storage.local.set({ enabledDomains });
          console.log(`[Scholic] ${domain} is now ${isEnabled ? "enabled" : "disabled"}`);
          if (isEnabled) {
            const sent = await chrome.tabs.sendMessage(tab.id, { type: "SET_ENABLED", enabled: true }).catch(() => null);
            if (!sent) {
              chrome.tabs.reload(tab.id);
            }
            return;
          }
          chrome.tabs.sendMessage(tab.id, { type: "SET_ENABLED", enabled: false }).catch(() => {
          });
        } catch (err) {
          console.warn("[Scholic] Could not toggle state:", err);
        }
      });
      async function updateBadge(tabId, count) {
        const text = count > 0 ? String(count) : "";
        await chrome.action.setBadgeText({ text, tabId });
        await chrome.action.setBadgeBackgroundColor({ color: "#6EB781", tabId });
      }
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === "UPDATE_BADGE") {
          if (sender.tab?.id) {
            updateBadge(sender.tab.id, message.data?.count || 0);
          }
          sendResponse({ ok: true });
          return true;
        }
        handleMessage(message).then((result) => {
          if (message.type === "FETCH_ANNOTATIONS" && sender.tab?.id && result?.annotations) {
            updateBadge(sender.tab.id, result.annotations.length);
          }
          sendResponse(result);
        }).catch((err) => {
          console.error("[Scholic] API error:", err);
          sendResponse({ error: err.message });
        });
        return true;
      });
      chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
        if (message.type === "SCHOLIC_EXT_AUTH" && message.token) {
          console.log("[Scholic] Received token from sync page:", sender?.url);
          chrome.storage.local.set({ scholicToken: message.token }).then(() => {
            sendResponse({ success: true, message: "Token saved" });
          });
          return true;
        }
      });
      async function handleMessage(message) {
        switch (message.type) {
          case "CREATE_ANNOTATION":
            return createAnnotation(message.data);
          case "FETCH_ANNOTATIONS":
            return fetchAnnotations(message.data.url, message.data.limit, message.data.offset);
          case "DELETE_ANNOTATION":
            return deleteAnnotation(message.data.id);
          case "CREATE_COMMENT":
            return createComment(message.data.annotationId, message.data.text);
          case "FETCH_ME":
            return apiRequest("/auth/me");
          case "CAPTURE_TAB":
            return captureVisibleTab();
          default:
            return { error: `Unknown message type: ${message.type}` };
        }
      }
      async function getAuthToken() {
        const result = await chrome.storage.local.get("scholicToken");
        return result.scholicToken || null;
      }
      async function apiRequest(path, options = {}) {
        const token = await getAuthToken();
        const headers = {
          "Content-Type": "application/json"
        };
        if (token) {
          headers["Authorization"] = `Bearer ${token}`;
        }
        const response = await fetch(`${API_BASE}${path}`, {
          ...options,
          headers: { ...headers, ...options.headers }
        });
        if (response.status === 401) {
          console.warn("[Scholic] Session expired or invalid (401). Clearing token.");
          await chrome.storage.local.remove("scholicToken");
          throw new Error("Authentication session expired. Please sign in again.");
        }
        if (!response.ok) {
          const errorBody = await response.text();
          throw new Error(`API error ${response.status}: ${errorBody}`);
        }
        return response.json();
      }
      async function createAnnotation(data) {
        const annotation = await apiRequest("/annotations", {
          method: "POST",
          body: JSON.stringify({
            url: data.url,
            quoteText: data.quoteText,
            text: data.text,
            selectors: JSON.stringify(data.selectors || []),
            isPrivate: data.isPrivate,
            type: data.type || "text",
            image: data.image,
            pdfHash: data.pdfHash,
            pdfPage: data.pdfPage,
            highlightColor: data.highlightColor || "#A8D5B5"
          })
        });
        return { annotation };
      }
      async function captureVisibleTab() {
        const dataUrl = await chrome.tabs.captureVisibleTab({ format: "png" });
        return { dataUrl };
      }
      async function fetchAnnotations(url, limit = 50, offset = 0) {
        const result = await apiRequest(
          `/annotations?url=${encodeURIComponent(url)}&limit=${limit}&offset=${offset}`
        );
        const rawAnnotations = result?.annotations || [];
        const total = result?.total ?? rawAnnotations.length;
        const parsed = rawAnnotations.map((a) => ({
          ...a,
          selectors: typeof a.selectors === "string" ? JSON.parse(a.selectors) : a.selectors
        }));
        return { annotations: parsed, total };
      }
      async function deleteAnnotation(id) {
        await apiRequest(`/annotations/${id}`, { method: "DELETE" });
        return { deleted: true };
      }
      async function createComment(annotationId, text) {
        const comment = await apiRequest(`/annotations/${annotationId}/comments`, {
          method: "POST",
          body: JSON.stringify({ text })
        });
        return { comment };
      }
    }
  });
  require_background();
})();
//# sourceMappingURL=background.js.map
