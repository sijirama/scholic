"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // node_modules/approx-string-match/build/src/index.js
  function reverse(s) {
    return s.split("").reverse().join("");
  }
  function findMatchStarts(text, pattern, matches) {
    const patRev = reverse(pattern);
    return matches.map((m) => {
      const minStart = Math.max(0, m.end - pattern.length - m.errors);
      const textRev = reverse(text.slice(minStart, m.end));
      const start = findMatchEnds(textRev, patRev, m.errors).reduce((min, rm) => {
        if (m.end - rm.end < min) {
          return m.end - rm.end;
        }
        return min;
      }, m.end);
      return {
        start,
        end: m.end,
        errors: m.errors
      };
    });
  }
  function oneIfNotZero(n) {
    return (n | -n) >> 31 & 1;
  }
  function advanceBlock(ctx, peq, b, hIn) {
    let pV = ctx.P[b];
    let mV = ctx.M[b];
    const hInIsNegative = hIn >>> 31;
    const eq = peq[b] | hInIsNegative;
    const xV = eq | mV;
    const xH = (eq & pV) + pV ^ pV | eq;
    let pH = mV | ~(xH | pV);
    let mH = pV & xH;
    const hOut = oneIfNotZero(pH & ctx.lastRowMask[b]) - oneIfNotZero(mH & ctx.lastRowMask[b]);
    pH <<= 1;
    mH <<= 1;
    mH |= hInIsNegative;
    pH |= oneIfNotZero(hIn) - hInIsNegative;
    pV = mH | ~(xV | pH);
    mV = pH & xV;
    ctx.P[b] = pV;
    ctx.M[b] = mV;
    return hOut;
  }
  function findMatchEnds(text, pattern, maxErrors) {
    if (pattern.length === 0) {
      return [];
    }
    maxErrors = Math.min(maxErrors, pattern.length);
    const matches = [];
    const w = 32;
    const bMax = Math.ceil(pattern.length / w) - 1;
    const ctx = {
      P: new Uint32Array(bMax + 1),
      M: new Uint32Array(bMax + 1),
      lastRowMask: new Uint32Array(bMax + 1)
    };
    ctx.lastRowMask.fill(1 << 31);
    ctx.lastRowMask[bMax] = 1 << (pattern.length - 1) % w;
    const emptyPeq = new Uint32Array(bMax + 1);
    const peq = /* @__PURE__ */ new Map();
    const asciiPeq = [];
    for (let i = 0; i < 256; i++) {
      asciiPeq.push(emptyPeq);
    }
    for (let c = 0; c < pattern.length; c += 1) {
      const val = pattern.charCodeAt(c);
      if (peq.has(val)) {
        continue;
      }
      const charPeq = new Uint32Array(bMax + 1);
      peq.set(val, charPeq);
      if (val < asciiPeq.length) {
        asciiPeq[val] = charPeq;
      }
      for (let b = 0; b <= bMax; b += 1) {
        charPeq[b] = 0;
        for (let r = 0; r < w; r += 1) {
          const idx = b * w + r;
          if (idx >= pattern.length) {
            continue;
          }
          const match = pattern.charCodeAt(idx) === val;
          if (match) {
            charPeq[b] |= 1 << r;
          }
        }
      }
    }
    let y = Math.max(0, Math.ceil(maxErrors / w) - 1);
    const score = new Uint32Array(bMax + 1);
    for (let b = 0; b <= y; b += 1) {
      score[b] = (b + 1) * w;
    }
    score[bMax] = pattern.length;
    for (let b = 0; b <= y; b += 1) {
      ctx.P[b] = ~0;
      ctx.M[b] = 0;
    }
    for (let j = 0; j < text.length; j += 1) {
      const charCode = text.charCodeAt(j);
      let charPeq;
      if (charCode < asciiPeq.length) {
        charPeq = asciiPeq[charCode];
      } else {
        charPeq = peq.get(charCode);
        if (typeof charPeq === "undefined") {
          charPeq = emptyPeq;
        }
      }
      let carry = 0;
      for (let b = 0; b <= y; b += 1) {
        carry = advanceBlock(ctx, charPeq, b, carry);
        score[b] += carry;
      }
      if (score[y] - carry <= maxErrors && y < bMax && (charPeq[y + 1] & 1 || carry < 0)) {
        y += 1;
        ctx.P[y] = ~0;
        ctx.M[y] = 0;
        let maxBlockScore;
        if (y === bMax) {
          const remainder = pattern.length % w;
          maxBlockScore = remainder === 0 ? w : remainder;
        } else {
          maxBlockScore = w;
        }
        score[y] = score[y - 1] + maxBlockScore - carry + advanceBlock(ctx, charPeq, y, carry);
      } else {
        while (y > 0 && score[y] >= maxErrors + w) {
          y -= 1;
        }
      }
      if (y === bMax && score[y] <= maxErrors) {
        if (score[y] < maxErrors) {
          matches.splice(0, matches.length);
        }
        matches.push({
          start: -1,
          end: j + 1,
          errors: score[y]
        });
        maxErrors = score[y];
      }
    }
    return matches;
  }
  function search(text, pattern, maxErrors) {
    const matches = findMatchEnds(text, pattern, maxErrors);
    return findMatchStarts(text, pattern, matches);
  }
  var init_src = __esm({
    "node_modules/approx-string-match/build/src/index.js"() {
    }
  });

  // src/anchoring/match-quote.ts
  function normalizeWhitespace(text) {
    return text.replace(/\s+/g, " ").trim();
  }
  function search2(text, str, maxErrors, options = {}) {
    if (typeof options.hint === "number") {
      const windowSize = options.windowSize || 4096;
      const startWindow = Math.max(0, options.hint - windowSize);
      const endWindow = Math.min(text.length, options.hint + windowSize);
      const subtext = text.slice(startWindow, endWindow);
      const matches = search2(subtext, str, maxErrors);
      if (matches.length > 0) {
        return matches.map((m) => ({
          ...m,
          start: m.start + startWindow,
          end: m.end + startWindow
        }));
      }
    }
    let matchPos = 0;
    const exactMatches = [];
    while (matchPos !== -1) {
      matchPos = text.indexOf(str, matchPos);
      if (matchPos !== -1) {
        exactMatches.push({
          start: matchPos,
          end: matchPos + str.length,
          errors: 0
        });
        matchPos += 1;
      }
    }
    if (exactMatches.length > 0) {
      return exactMatches;
    }
    return search(text, str, maxErrors);
  }
  function textMatchScore(text, str) {
    if (str.length === 0 || text.length === 0) {
      return 0;
    }
    const normText = normalizeWhitespace(text);
    const normStr = normalizeWhitespace(str);
    if (normStr.length === 0) return 1;
    const matches = search2(normText, normStr, normStr.length);
    return 1 - matches[0].errors / normStr.length;
  }
  function matchQuote(text, quote, context = {}) {
    if (quote.length === 0) {
      return null;
    }
    const normText = normalizeWhitespace(text);
    const normQuote = normalizeWhitespace(quote);
    if (normQuote.length === 0) return null;
    const maxErrors = Math.min(256, Math.ceil(normQuote.length * 0.25));
    const matches = search2(normText, normQuote, maxErrors, { hint: context.hint });
    if (matches.length === 0) {
      const fallbackMatches = search2(normText, normQuote, maxErrors);
      if (fallbackMatches.length === 0) return null;
      matches.push(...fallbackMatches);
    }
    const scoreMatch = (match) => {
      const quoteWeight = 50;
      const prefixWeight = 20;
      const suffixWeight = 20;
      const posWeight = 10;
      const quoteScore = 1 - match.errors / normQuote.length;
      const prefixScore = context.prefix ? textMatchScore(
        normText.slice(
          Math.max(0, match.start - context.prefix.length * 2),
          match.start
        ),
        context.prefix
      ) : 1;
      const suffixScore = context.suffix ? textMatchScore(
        normText.slice(match.end, match.end + context.suffix.length * 2),
        context.suffix
      ) : 1;
      let posScore = 1;
      if (typeof context.hint === "number") {
        const offset = Math.abs(match.start - context.hint);
        posScore = 1 - Math.min(1, offset / normText.length);
      }
      const rawScore = quoteWeight * quoteScore + prefixWeight * prefixScore + suffixWeight * suffixScore + posWeight * posScore;
      const maxScore = quoteWeight + prefixWeight + suffixWeight + posWeight;
      return rawScore / maxScore;
    };
    const scoredMatches = matches.map((m) => ({
      start: m.start,
      end: m.end,
      score: scoreMatch(m)
    }));
    scoredMatches.sort((a, b) => b.score - a.score);
    const bestMatch = scoredMatches[0];
    if (bestMatch.score < 0.5) return null;
    return {
      start: findNearestOffset(text, bestMatch.start),
      end: findNearestOffset(text, bestMatch.end, true),
      score: bestMatch.score
    };
  }
  function findNearestOffset(text, normIndex, isEnd = false) {
    let normPos = 0;
    let started = false;
    let inWhitespace = true;
    for (let i = 0; i < text.length; i++) {
      const isWs = /\s/.test(text[i]);
      if (isWs) {
        if (started && !inWhitespace) {
          if (normPos === normIndex) return i;
          normPos++;
          inWhitespace = true;
        }
      } else {
        if (!started) started = true;
        inWhitespace = false;
        if (normPos === normIndex) return i;
        normPos++;
      }
    }
    return text.length;
  }
  var init_match_quote = __esm({
    "src/anchoring/match-quote.ts"() {
      "use strict";
      init_src();
    }
  });

  // src/anchoring/text-range.ts
  function nodeTextLength(node) {
    switch (node.nodeType) {
      case Node.ELEMENT_NODE:
      case Node.TEXT_NODE:
        return node.textContent?.length ?? 0;
      default:
        return 0;
    }
  }
  function previousSiblingsTextLength(node) {
    let sibling = node.previousSibling;
    let length = 0;
    while (sibling) {
      length += nodeTextLength(sibling);
      sibling = sibling.previousSibling;
    }
    return length;
  }
  function resolveOffsets(element, ...offsets) {
    let nextOffset = offsets.shift();
    const nodeIter = element.ownerDocument.createNodeIterator(
      element,
      NodeFilter.SHOW_TEXT
    );
    const results = [];
    let currentNode = nodeIter.nextNode();
    let textNode;
    let length = 0;
    while (nextOffset !== void 0 && currentNode) {
      textNode = currentNode;
      if (length + textNode.data.length > nextOffset) {
        results.push({ node: textNode, offset: nextOffset - length });
        nextOffset = offsets.shift();
      } else {
        currentNode = nodeIter.nextNode();
        length += textNode.data.length;
      }
    }
    while (nextOffset !== void 0 && textNode && length === nextOffset) {
      results.push({ node: textNode, offset: textNode.data.length });
      nextOffset = offsets.shift();
    }
    if (nextOffset !== void 0) {
      throw new RangeError("Offset exceeds text length");
    }
    return results;
  }
  var TextPosition, TextRange;
  var init_text_range = __esm({
    "src/anchoring/text-range.ts"() {
      "use strict";
      TextPosition = class _TextPosition {
        /** The element this offset is relative to */
        element;
        /** Character offset from the start of element.textContent */
        offset;
        constructor(element, offset) {
          if (offset < 0) {
            throw new Error("Offset is invalid");
          }
          this.element = element;
          this.offset = offset;
        }
        /**
         * Return a copy of this position with offset relative to an ancestor element.
         * This "walks up" the DOM, adding sibling text lengths at each level.
         *
         * @param parent - Must be an ancestor of this.element
         */
        relativeTo(parent) {
          if (!parent.contains(this.element)) {
            throw new Error("Parent is not an ancestor of current element");
          }
          let el = this.element;
          let offset = this.offset;
          while (el !== parent) {
            offset += previousSiblingsTextLength(el);
            el = el.parentElement;
          }
          return new _TextPosition(el, offset);
        }
        /**
         * Resolve this position to a specific (textNode, localOffset) pair.
         * This is the reverse of the constructor — it finds the exact text node.
         *
         * @param options.direction - Specifies in which direction to search for the
         *                            nearest text node if `this.offset` is 0 and
         *                            `this.element` has no text.
         * @throws RangeError if offset exceeds element's text length
         */
        resolve(options = {}) {
          try {
            return resolveOffsets(this.element, this.offset)[0];
          } catch (err) {
            if (this.offset === 0 && options.direction !== void 0) {
              const tw = document.createTreeWalker(
                this.element.getRootNode(),
                NodeFilter.SHOW_TEXT
              );
              tw.currentNode = this.element;
              const forwards = options.direction === 1 /* FORWARDS */;
              const text = forwards ? tw.nextNode() : tw.previousNode();
              if (!text) {
                throw err;
              }
              return { node: text, offset: forwards ? 0 : text.data.length };
            } else {
              throw err;
            }
          }
        }
        /**
         * Create a TextPosition from a character offset within a node.
         * If `node` is a text node, the offset is relative to that text node's parent.
         */
        static fromCharOffset(node, offset) {
          switch (node.nodeType) {
            case Node.TEXT_NODE:
              return _TextPosition.fromPoint(node, offset);
            case Node.ELEMENT_NODE:
              return new _TextPosition(node, offset);
            default:
              throw new Error("Node is not an element or text node");
          }
        }
        /**
         * Create a TextPosition from a DOM Range boundary point (node, offset).
         * Converts the range point to a character offset within the parent element.
         */
        static fromPoint(node, offset) {
          switch (node.nodeType) {
            case Node.TEXT_NODE: {
              if (offset < 0 || offset > node.data.length) {
                throw new Error("Text node offset is out of range");
              }
              if (!node.parentElement) {
                throw new Error("Text node has no parent");
              }
              const textOffset = previousSiblingsTextLength(node) + offset;
              return new _TextPosition(node.parentElement, textOffset);
            }
            case Node.ELEMENT_NODE: {
              if (offset < 0 || offset > node.childNodes.length) {
                throw new Error("Child node offset is out of range");
              }
              let textOffset = 0;
              for (let i = 0; i < offset; i++) {
                textOffset += nodeTextLength(node.childNodes[i]);
              }
              return new _TextPosition(node, textOffset);
            }
            default:
              throw new Error("Point is not in an element or text node");
          }
        }
      };
      TextRange = class _TextRange {
        start;
        end;
        constructor(start, end) {
          this.start = start;
          this.end = end;
        }
        /**
         * Create a new TextRange with offsets relative to `element`.
         * Both start and end elements must be descendants of `element`.
         */
        relativeTo(element) {
          return new _TextRange(
            this.start.relativeTo(element),
            this.end.relativeTo(element)
          );
        }
        /**
         * Convert this TextRange to a DOM Range.
         * The resulting Range will start and end in text nodes.
         */
        toRange() {
          let start;
          let end;
          if (this.start.element === this.end.element && this.start.offset <= this.end.offset) {
            [start, end] = resolveOffsets(
              this.start.element,
              this.start.offset,
              this.end.offset
            );
          } else {
            start = this.start.resolve({
              direction: 1 /* FORWARDS */
            });
            end = this.end.resolve({ direction: 2 /* BACKWARDS */ });
          }
          const range = new Range();
          range.setStart(start.node, start.offset);
          range.setEnd(end.node, end.offset);
          return range;
        }
        /**
         * Create a TextRange from a DOM Range.
         */
        static fromRange(range) {
          const start = TextPosition.fromPoint(
            range.startContainer,
            range.startOffset
          );
          const end = TextPosition.fromPoint(range.endContainer, range.endOffset);
          return new _TextRange(start, end);
        }
        /**
         * Create a TextRange from absolute character offsets within `root`.
         */
        static fromOffsets(root, start, end) {
          return new _TextRange(
            new TextPosition(root, start),
            new TextPosition(root, end)
          );
        }
      };
    }
  });

  // src/anchoring/xpath.ts
  function getNodeName(node) {
    const nodeName = node.nodeName.toLowerCase();
    return nodeName === "#text" ? "text()" : nodeName;
  }
  function getNodePosition(node) {
    let pos = 0;
    let tmp = node;
    while (tmp) {
      if (tmp.nodeName === node.nodeName) {
        pos += 1;
      }
      tmp = tmp.previousSibling;
    }
    return pos;
  }
  function getPathSegment(node) {
    const name = getNodeName(node);
    const pos = getNodePosition(node);
    return `${name}[${pos}]`;
  }
  function xpathFromNode(node, root) {
    let xpath = "";
    let elem = node;
    while (elem !== root) {
      if (!elem) {
        throw new Error("Node is not a descendant of root");
      }
      xpath = getPathSegment(elem) + "/" + xpath;
      elem = elem.parentNode;
    }
    xpath = "/" + xpath;
    xpath = xpath.replace(/\/$/, "");
    return xpath;
  }
  function nthChildOfType(element, nodeName, index) {
    nodeName = nodeName.toUpperCase();
    let matchIndex = -1;
    for (let i = 0; i < element.children.length; i++) {
      const child = element.children[i];
      if (child.nodeName.toUpperCase() === nodeName) {
        ++matchIndex;
        if (matchIndex === index) {
          return child;
        }
      }
    }
    return null;
  }
  function evaluateSimpleXPath(xpath, root) {
    const isSimpleXPath = xpath.match(/^(\/([A-Za-z0-9-]+|text\(\))(\[[0-9]+\])?)+$/) !== null;
    if (!isSimpleXPath) {
      throw new Error("Expression is not a simple XPath");
    }
    const segments = xpath.split("/");
    let currentNode = root;
    segments.shift();
    for (const segment of segments) {
      let nodeName;
      let nodeIndex;
      const separatorPos = segment.indexOf("[");
      if (separatorPos !== -1) {
        nodeName = segment.slice(0, separatorPos);
        const indexStr = segment.slice(separatorPos + 1, segment.indexOf("]"));
        nodeIndex = parseInt(indexStr) - 1;
        if (nodeIndex < 0) {
          return null;
        }
      } else {
        nodeName = segment;
        nodeIndex = 0;
      }
      if (nodeName === "text()") {
        let textIndex = 0;
        let found = false;
        for (let i = 0; i < currentNode.childNodes.length; i++) {
          const child = currentNode.childNodes[i];
          if (child.nodeType === Node.TEXT_NODE) {
            if (textIndex === nodeIndex) {
              currentNode = child;
              found = true;
              break;
            }
            textIndex++;
          }
        }
        if (!found) {
          return null;
        }
      } else {
        if (currentNode.nodeType !== Node.ELEMENT_NODE) {
          return null;
        }
        const child = nthChildOfType(currentNode, nodeName, nodeIndex);
        if (!child) {
          return null;
        }
        currentNode = child;
      }
    }
    return currentNode;
  }
  function nodeFromXPath(xpath, root = document.body) {
    try {
      return evaluateSimpleXPath(xpath, root);
    } catch {
      return document.evaluate(
        "." + xpath,
        root,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE,
        null
      ).singleNodeValue;
    }
  }
  var init_xpath = __esm({
    "src/anchoring/xpath.ts"() {
      "use strict";
    }
  });

  // src/anchoring/anchors.ts
  var RangeAnchor, TextPositionAnchor, TextQuoteAnchor;
  var init_anchors = __esm({
    "src/anchoring/anchors.ts"() {
      "use strict";
      init_match_quote();
      init_text_range();
      init_xpath();
      RangeAnchor = class _RangeAnchor {
        root;
        range;
        constructor(root, range) {
          this.root = root;
          this.range = range;
        }
        /** Create a RangeAnchor from a live DOM Range (e.g., user's selection). */
        static fromRange(root, range) {
          return new _RangeAnchor(root, range);
        }
        /** Create a RangeAnchor from a stored RangeSelector (from the backend). */
        static fromSelector(root, selector) {
          const startContainer = nodeFromXPath(selector.startContainer, root);
          if (!startContainer) {
            throw new Error("Failed to resolve startContainer XPath");
          }
          const endContainer = nodeFromXPath(selector.endContainer, root);
          if (!endContainer) {
            throw new Error("Failed to resolve endContainer XPath");
          }
          const startPos = TextPosition.fromCharOffset(
            startContainer,
            selector.startOffset
          );
          const endPos = TextPosition.fromCharOffset(
            endContainer,
            selector.endOffset
          );
          const range = new TextRange(startPos, endPos).toRange();
          return new _RangeAnchor(root, range);
        }
        /** Return the DOM Range. */
        toRange() {
          return this.range;
        }
        /** Serialize to a RangeSelector (XPath + character offsets). */
        toSelector() {
          const normalizedRange = TextRange.fromRange(this.range).toRange();
          const textRange = TextRange.fromRange(normalizedRange);
          const startContainer = xpathFromNode(textRange.start.element, this.root);
          const endContainer = xpathFromNode(textRange.end.element, this.root);
          return {
            type: "RangeSelector",
            startContainer,
            startOffset: textRange.start.offset,
            endContainer,
            endOffset: textRange.end.offset
          };
        }
      };
      TextPositionAnchor = class _TextPositionAnchor {
        root;
        start;
        end;
        constructor(root, start, end) {
          this.root = root;
          this.start = start;
          this.end = end;
        }
        /** Create from a DOM Range by computing character offsets relative to root. */
        static fromRange(root, range) {
          const textRange = TextRange.fromRange(range).relativeTo(root);
          return new _TextPositionAnchor(
            root,
            textRange.start.offset,
            textRange.end.offset
          );
        }
        /** Create from a stored TextPositionSelector. */
        static fromSelector(root, selector) {
          return new _TextPositionAnchor(root, selector.start, selector.end);
        }
        /** Serialize to a TextPositionSelector. */
        toSelector() {
          return {
            type: "TextPositionSelector",
            start: this.start,
            end: this.end
          };
        }
        /** Resolve to a DOM Range. */
        toRange() {
          return TextRange.fromOffsets(this.root, this.start, this.end).toRange();
        }
      };
      TextQuoteAnchor = class _TextQuoteAnchor {
        root;
        exact;
        context;
        constructor(root, exact, context = {}) {
          this.root = root;
          this.exact = exact;
          this.context = context;
        }
        /**
         * Create from a DOM Range by extracting the text and 32 chars of surrounding context.
         */
        static fromRange(root, range) {
          const text = root.textContent;
          const textRange = TextRange.fromRange(range).relativeTo(root);
          const start = textRange.start.offset;
          const end = textRange.end.offset;
          const contextLen = 32;
          return new _TextQuoteAnchor(root, text.slice(start, end), {
            prefix: text.slice(Math.max(0, start - contextLen), start),
            suffix: text.slice(end, Math.min(text.length, end + contextLen))
          });
        }
        /** Create from a stored TextQuoteSelector. */
        static fromSelector(root, selector) {
          const { prefix, suffix } = selector;
          return new _TextQuoteAnchor(root, selector.exact, { prefix, suffix });
        }
        /** Serialize to a TextQuoteSelector. */
        toSelector() {
          return {
            type: "TextQuoteSelector",
            exact: this.exact,
            prefix: this.context.prefix,
            suffix: this.context.suffix
          };
        }
        /**
         * Resolve to a DOM Range using fuzzy text matching.
         * This is where the magic happens for surviving page edits.
         */
        toRange(options = {}) {
          return this.toPositionAnchor(options).toRange();
        }
        /**
         * Find the best match for this quote in the document text,
         * then return it as a TextPositionAnchor.
         */
        toPositionAnchor(options = {}) {
          const text = this.root.textContent;
          const match = matchQuote(text, this.exact, {
            ...this.context,
            hint: options.hint
          });
          if (!match) {
            throw new Error("Quote not found");
          }
          return new TextPositionAnchor(this.root, match.start, match.end);
        }
      };
    }
  });

  // src/anchoring/index.ts
  function describe(root, range) {
    const selectors = [];
    try {
      const rangeAnchor = RangeAnchor.fromRange(root, range);
      selectors.push(rangeAnchor.toSelector());
    } catch {
    }
    try {
      const positionAnchor = TextPositionAnchor.fromRange(root, range);
      selectors.push(positionAnchor.toSelector());
    } catch {
    }
    try {
      const quoteAnchor = TextQuoteAnchor.fromRange(root, range);
      selectors.push(quoteAnchor.toSelector());
    } catch {
    }
    return selectors;
  }
  async function anchor(root, selectors) {
    let position = null;
    let quote = null;
    let rangeSelector = null;
    for (const selector of selectors) {
      switch (selector.type) {
        case "RangeSelector":
          rangeSelector = selector;
          break;
        case "TextPositionSelector":
          position = selector;
          break;
        case "TextQuoteSelector":
          quote = selector;
          break;
      }
    }
    let promise = Promise.reject(new Error("No selectors"));
    if (rangeSelector && rangeSelector.type === "RangeSelector") {
      const sel = rangeSelector;
      promise = promise.catch(() => {
        const anchor2 = RangeAnchor.fromSelector(root, sel);
        const range = anchor2.toRange();
        if (quote && quote.type === "TextQuoteSelector" && quote.exact) {
          if (range.toString() !== quote.exact) {
            throw new Error("Quote mismatch after Range anchor");
          }
        }
        return range;
      });
    }
    if (position) {
      const pos = position;
      promise = promise.catch(() => {
        const anchor2 = TextPositionAnchor.fromSelector(root, pos);
        const range = anchor2.toRange();
        if (quote && quote.type === "TextQuoteSelector" && quote.exact) {
          if (range.toString() !== quote.exact) {
            throw new Error("Quote mismatch after Position anchor");
          }
        }
        return range;
      });
    }
    if (quote && quote.type === "TextQuoteSelector") {
      const q = quote;
      promise = promise.catch(() => {
        const anchor2 = TextQuoteAnchor.fromSelector(root, q);
        return anchor2.toRange({ hint: position?.start });
      });
    }
    return promise;
  }
  var init_anchoring = __esm({
    "src/anchoring/index.ts"() {
      "use strict";
      init_anchors();
    }
  });

  // src/range-util.ts
  function isNodeInRange(range, node) {
    try {
      const length = node.nodeValue?.length ?? node.childNodes.length;
      return (
        // Check start of node is before end of range.
        range.comparePoint(node, 0) <= 0 && // Check end of node is after start of range.
        range.comparePoint(node, length) >= 0
      );
    } catch {
      return false;
    }
  }
  var init_range_util = __esm({
    "src/range-util.ts"() {
      "use strict";
    }
  });

  // src/highlighter.ts
  function wholeTextNodesInRange(range) {
    if (range.collapsed) {
      return [];
    }
    let root = range.commonAncestorContainer;
    if (root && root.nodeType !== Node.ELEMENT_NODE) {
      root = root.parentElement;
    }
    if (!root) {
      return [];
    }
    const textNodes = [];
    const nodeIter = root.ownerDocument.createNodeIterator(
      root,
      NodeFilter.SHOW_TEXT
      // Only return Text nodes
    );
    let node;
    while (node = nodeIter.nextNode()) {
      if (!isNodeInRange(range, node)) {
        continue;
      }
      const text = node;
      if (text === range.startContainer && range.startOffset > 0) {
        text.splitText(range.startOffset);
        continue;
      }
      if (text === range.endContainer && range.endOffset < text.data.length) {
        text.splitText(range.endOffset);
      }
      textNodes.push(text);
    }
    return textNodes;
  }
  function highlightRange(range, cssClass = "scholic-annotation", annotationId) {
    const textNodes = wholeTextNodesInRange(range);
    if (textNodes.length === 0) {
      return [];
    }
    const textNodeSpans = [];
    let currentSpan = null;
    let prevNode = null;
    textNodes.forEach((node) => {
      if (prevNode && prevNode.nextSibling === node) {
        currentSpan.push(node);
      } else {
        currentSpan = [node];
        textNodeSpans.push(currentSpan);
      }
      prevNode = node;
    });
    const whitespace = /^\s*$/;
    const filteredSpans = textNodeSpans.filter((span) => {
      const parentElement = span[0].parentElement;
      return (
        // Whitespace <span>s should be highlighted since they affect layout in
        // some code editors
        parentElement?.childNodes.length === 1 && parentElement?.tagName === "SPAN" || // Otherwise ignore white-space only Text node spans
        span.some((node) => !whitespace.test(node.data))
      );
    });
    const highlights = [];
    filteredSpans.forEach((nodes) => {
      const highlightEl = document.createElement(
        "scholic-highlight"
      );
      highlightEl.className = `scholic-highlight ${cssClass}`;
      if (annotationId) {
        highlightEl._scholicAnnotationId = annotationId;
        highlightEl.dataset.annotationId = annotationId;
      }
      const parent = nodes[0].parentNode;
      parent.replaceChild(highlightEl, nodes[0]);
      nodes.forEach((node) => highlightEl.appendChild(node));
      highlights.push(highlightEl);
    });
    return highlights;
  }
  function removeHighlights(highlights) {
    for (const h of highlights) {
      if (h.parentNode) {
        const children = Array.from(h.childNodes);
        const parent = h.parentNode;
        children.forEach((child) => parent.insertBefore(child, h));
        parent.removeChild(h);
        parent.normalize();
      }
    }
  }
  function getHighlightsForAnnotation(annotationId) {
    return Array.from(
      document.querySelectorAll(
        `scholic-highlight[data-annotation-id="${annotationId}"]`
      )
    );
  }
  var init_highlighter = __esm({
    "src/highlighter.ts"() {
      "use strict";
      init_range_util();
    }
  });

  // src/popover.ts
  var SelectionPopover;
  var init_popover = __esm({
    "src/popover.ts"() {
      "use strict";
      SelectionPopover = class {
        /** The shadow host element injected into the page */
        host = null;
        /** The shadow root for style isolation */
        shadow = null;
        /** The popover container element */
        container = null;
        /** Callbacks for button actions */
        callbacks;
        constructor(callbacks) {
          this.callbacks = callbacks;
        }
        /**
         * Show the popover near the user's text selection.
         *
         * Positions it just above the selection's bounding rect.
         * If the selection is near the top of the viewport, positions below instead.
         *
         * @param range - The user's selection Range
         */
        show(range) {
          this.hide();
          const quoteText = range.toString().trim();
          if (!quoteText) return;
          this.host = document.createElement("scholic-popover-host");
          this.host.style.cssText = "position: absolute; z-index: 2147483647;";
          this.shadow = this.host.attachShadow({ mode: "closed" });
          const style = document.createElement("style");
          style.textContent = `
      /* Popover container */
      .scholic-popover {
        display: flex;
        align-items: center;
        gap: 4px;
        padding: 6px 8px;
        background: #1a1a1a;
        border: 1px solid rgba(255,255,255,0.12);
        border-radius: 8px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.4);
        font-family: 'Inter', -apple-system, sans-serif;
        animation: scholic-fade-in 0.15s ease;
      }

      @keyframes scholic-fade-in {
        from { opacity: 0; transform: translateY(4px); }
        to   { opacity: 1; transform: translateY(0); }
      }

      /* Popover button base */
      .scholic-popover-btn {
        display: flex;
        align-items: center;
        gap: 5px;
        padding: 5px 12px;
        border: none;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s ease;
        font-family: inherit;
      }

      /* "Annotate" button \u2014 primary green */
      .scholic-popover-btn.annotate {
        background: #6EB781;
        color: #fff;
      }
      .scholic-popover-btn.annotate:hover {
        background: #5da870;
      }

      /* "Highlight" button \u2014 subtle outline */
      .scholic-popover-btn.highlight {
        background: transparent;
        color: #ccc;
        border: 1px solid rgba(255,255,255,0.15);
      }
      .scholic-popover-btn.highlight:hover {
        background: rgba(255,255,255,0.06);
      }

      /* Icon size */
      .scholic-popover-btn svg {
        width: 14px;
        height: 14px;
      }
    `;
          this.shadow.appendChild(style);
          this.container = document.createElement("div");
          this.container.className = "scholic-popover";
          const annotateBtn = document.createElement("button");
          annotateBtn.className = "scholic-popover-btn annotate";
          annotateBtn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
      </svg>
      Annotate
    `;
          annotateBtn.addEventListener("mousedown", (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.callbacks.onAnnotate(range, quoteText);
            this.hide();
          });
          const highlightBtn = document.createElement("button");
          highlightBtn.className = "scholic-popover-btn highlight";
          highlightBtn.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2z"/>
      </svg>
      Highlight
    `;
          highlightBtn.addEventListener("mousedown", (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.callbacks.onHighlight(range, quoteText);
            this.hide();
          });
          this.container.appendChild(annotateBtn);
          this.container.appendChild(highlightBtn);
          this.shadow.appendChild(this.container);
          const rect = range.getBoundingClientRect();
          const scrollX = window.scrollX;
          const scrollY = window.scrollY;
          this.host.style.left = `${rect.left + scrollX + rect.width / 2 - 80}px`;
          if (rect.top < 60) {
            this.host.style.top = `${rect.bottom + scrollY + 8}px`;
          } else {
            this.host.style.top = `${rect.top + scrollY - 46}px`;
          }
          document.body.appendChild(this.host);
          this.scrollHandler = () => this.hide();
          window.addEventListener("scroll", this.scrollHandler, { once: true, passive: true });
        }
        scrollHandler = null;
        /**
         * Hide and remove the popover from the DOM.
         */
        hide() {
          if (this.scrollHandler) {
            window.removeEventListener("scroll", this.scrollHandler);
            this.scrollHandler = null;
          }
          if (this.host && this.host.parentNode) {
            this.host.parentNode.removeChild(this.host);
          }
          this.host = null;
          this.shadow = null;
          this.container = null;
        }
      };
    }
  });

  // src/config.ts
  var CONFIG;
  var init_config = __esm({
    "src/config.ts"() {
      "use strict";
      CONFIG = {
        // The backend API endpoint
        API_BASE: "https://api.scholic.com/api",
        // The frontend web application URL (for profile links and login)
        WEB_URL: "https://scholic.com"
      };
    }
  });

  // src/sidebar.ts
  function timeAgo(dateStr) {
    const date = new Date(dateStr);
    const now = /* @__PURE__ */ new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1e3);
    const diffMin = Math.floor(diffSec / 60);
    const diffHr = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHr / 24);
    if (diffSec < 60) return "just now";
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHr < 24) return `${diffHr}h ago`;
    if (diffDay === 1) return "yesterday";
    if (diffDay < 7) return `${diffDay}d ago`;
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  }
  var HIGHLIGHT_COLORS, ICONS, Sidebar;
  var init_sidebar = __esm({
    "src/sidebar.ts"() {
      "use strict";
      init_config();
      HIGHLIGHT_COLORS = [
        // Pastels (light backgrounds)
        { name: "Sage", hex: "#A8D5B5" },
        { name: "Butter", hex: "#F5E4A0" },
        { name: "Sky", hex: "#A3C4F3" },
        { name: "Lilac", hex: "#C5A8D5" },
        { name: "Peach", hex: "#F5C4A3" },
        { name: "Rose", hex: "#F5A8C0" },
        // Deeper tones (light mode papers / dark backgrounds)
        { name: "Forest", hex: "#4A9B6F" },
        { name: "Amber", hex: "#D4A017" },
        { name: "Ocean", hex: "#2E7BC4" },
        { name: "Plum", hex: "#8B4BAF" },
        { name: "Coral", hex: "#E8603C" },
        { name: "Crimson", hex: "#C0392B" }
      ];
      ICONS = {
        lock: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
        globe: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`,
        pen: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>`,
        trash: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
        camera: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>`
      };
      Sidebar = class {
        /** Shadow host element */
        host;
        /** Shadow root for style isolation */
        shadow;
        /** The sidebar container */
        panel;
        /** Current annotation form state */
        pendingQuoteText = "";
        pendingSelectors = [];
        /** Callbacks */
        callbacks;
        /** Whether the sidebar is currently visible */
        isOpen = false;
        /** Current user data */
        userData = null;
        isRendering = false;
        /** Active tab: 'mine' | 'community' | 'all' */
        activeTab = "mine";
        isAuthenticated = false;
        /** Stored document click handler for cleanup */
        menuCloseHandler = null;
        constructor(callbacks) {
          this.callbacks = callbacks;
          this.fetchUserData();
          this.host = document.createElement("scholic-sidebar-host");
          this.host.style.cssText = `
      position: fixed;
      top: 0;
      right: 0;
      width: 0;
      height: 100vh;
      z-index: 2147483646;
      pointer-events: none;
    `;
          this.shadow = this.host.attachShadow({ mode: "closed" });
          const style = document.createElement("style");
          style.textContent = this.getStyles();
          this.shadow.appendChild(style);
          this.panel = document.createElement("div");
          this.panel.className = "scholic-sidebar";
          this.shadow.appendChild(this.panel);
          this.panel.innerHTML = `
      <div class="peek-indicator">${ICONS.globe}</div>
      <div class="sidebar-main-content" style="flex: 1; display: flex; flex-direction: column; min-width: 0;">
        <div class="sidebar-header-container" style="flex-shrink: 0;"></div>
        <div class="sidebar-tabs-container" style="flex-shrink: 0;"></div>
        <div class="sidebar-form-container" style="flex-shrink: 0;"></div>
        <div class="sidebar-image-preview-container" style="flex-shrink: 0; display: none; padding: 0 20px 16px;"></div>
        <div class="sidebar-list-container"></div>
      </div>
    `;
          this.panel.style.display = "flex";
          this.panel.style.flexDirection = "row";
          this.panel.style.position = "fixed";
          this.panel.style.alignItems = "stretch";
          document.body.appendChild(this.host);
          chrome.storage.onChanged.addListener((changes, area) => {
            if (area === "local" && changes.scholicToken) {
              console.log("[Scholic] Token changed, refreshing sidebar data...");
              this.isAuthenticated = !!changes.scholicToken.newValue;
              if (!this.isAuthenticated) {
                this.activeTab = "all";
              }
              this.fetchUserData();
            }
          });
        }
        /** Fetch current user data from the backend.
         * Also sets isAuthenticated so that the first renderAnnotationList call
         * has the correct auth state (avoids the race where the sidebar banner
         * shows "Sign in" while private annotations are already displayed). */
        async fetchUserData() {
          const result = await chrome.storage.local.get("scholicToken");
          const token = result.scholicToken;
          this.isAuthenticated = !!token;
          if (!token) {
            this.userData = null;
            if (this.activeTab !== "all") {
              this.activeTab = "all";
            }
            return;
          }
          try {
            const response = await chrome.runtime.sendMessage({
              type: "FETCH_ME"
            });
            if (response && !response.error) {
              this.userData = response;
              if (this.lastAnnotations.length > 0) {
                this.renderAnnotationList(this.lastAnnotations);
              }
            }
          } catch (err) {
            console.error("[Scholic] Failed to fetch user data:", err);
          }
        }
        /** Render the sidebar header with title and user menu */
        renderHeader() {
          const container = this.panel.querySelector(".sidebar-header-container");
          if (!container) return;
          container.innerHTML = "";
          const header = document.createElement("div");
          header.className = "sidebar-header";
          let userHtml = "";
          if (this.userData) {
            const initial = (this.userData.username || this.userData.email || "?")[0].toUpperCase();
            const avatarHtml = this.userData.profilePicture ? `<img src="${this.userData.profilePicture}" alt="Avatar" style="width:100%; height:100%; border-radius:50%; object-fit:cover;" />` : initial;
            userHtml = `
        <div class="user-profile">
          <div class="user-avatar" id="user-avatar-trigger">${avatarHtml}</div>
          <div class="user-menu" id="user-side-menu">
            <div class="user-email">${this.userData.email}</div>
            <button class="menu-item" id="logout-trigger">Log out</button>
          </div>
        </div>
      `;
          }
          const logoSvg = `
      <svg width="24" height="24" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="28" cy="10" r="5" fill="#E8C547" />
        <circle cx="42" cy="18" r="5" fill="#E87347" />
        <circle cx="44" cy="34" r="5" fill="#6EB781" />
        <circle cx="34" cy="46" r="5" fill="#47A3E8" />
        <circle cx="18" cy="44" r="5" fill="#9B6EB7" />
        <circle cx="12" cy="28" r="5" fill="#E8477A" />
        <circle cx="18" cy="16" r="5" fill="#47E8C5" />
        <circle cx="30" cy="28" r="3.5" fill="#6EB781" />
      </svg>
    `;
          header.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        ${logoSvg}
        <span class="sidebar-title" style="text-transform: lowercase; font-weight: 700; font-size: 15px; color: #6EB781;">scholic</span>
      </div>
      <div style="display: flex; align-items: center; gap: 12px;">
        <button class="screenshot-btn" title="Take a screenshot annotation" style="background:none; border:none; color:#888; cursor:pointer; padding:4px; display:flex; align-items:center;">
          ${ICONS.camera}
        </button>
        ${userHtml}
        <button class="sidebar-close">\u2715</button>
      </div>
    `;
          header.querySelector(".sidebar-close")?.addEventListener("click", () => {
            this.close();
          });
          const avatar = header.querySelector("#user-avatar-trigger");
          const menu = header.querySelector("#user-side-menu");
          avatar?.addEventListener("click", (e) => {
            e.stopPropagation();
            menu?.classList.toggle("show");
          });
          header.querySelector("#logout-trigger")?.addEventListener("click", async () => {
            await chrome.storage.local.remove("scholicToken");
            this.userData = null;
            this.renderAnnotationList([]);
            window.postMessage({ type: "SCHOLIC_LOGOUT_SUCCESS" }, "*");
          });
          if (this.menuCloseHandler) {
            document.removeEventListener("click", this.menuCloseHandler);
          }
          this.menuCloseHandler = () => menu?.classList.remove("show");
          document.addEventListener("click", this.menuCloseHandler);
          container.appendChild(header);
          const tabsContainer = this.panel.querySelector(".sidebar-tabs-container");
          if (!tabsContainer) return;
          tabsContainer.innerHTML = "";
          const tabs = document.createElement("div");
          tabs.className = "sidebar-tabs";
          let tabsHtml = "";
          if (this.isAuthenticated) {
            tabsHtml = `
        <button class="tab-btn ${this.activeTab === "mine" ? "active" : ""}" data-tab="mine">Mine</button>
        <button class="tab-btn ${this.activeTab === "community" ? "active" : ""}" data-tab="community">Following</button>
      `;
          }
          tabsHtml += `<button class="tab-btn ${this.activeTab === "all" ? "active" : ""}" data-tab="all">All</button>`;
          tabs.innerHTML = `
      ${tabsHtml}
      <button class="refresh-btn" title="Refresh annotations">
        <svg fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
      </button>
    `;
          tabs.querySelectorAll(".tab-btn").forEach((btn) => {
            btn.addEventListener("click", (e) => {
              const target = e.currentTarget;
              const tab = target.dataset.tab;
              if (this.activeTab !== tab) {
                this.activeTab = tab;
                this.isRendering = false;
                this.renderAnnotationList(this.lastAnnotations);
                this.callbacks.onTabChange(tab);
              }
            });
          });
          tabs.querySelector(".refresh-btn")?.addEventListener("click", (e) => {
            const btn = e.currentTarget;
            btn.classList.add("spinning");
            setTimeout(() => btn.classList.remove("spinning"), 500);
            this.callbacks.onRefresh();
          });
          tabsContainer.appendChild(tabs);
          header.querySelector(".screenshot-btn")?.addEventListener("click", () => {
            window.dispatchEvent(new CustomEvent("SCHOLIC_START_SCREENSHOT"));
          });
        }
        /** Cache of the most recent annotations for re-rendering on auth change */
        lastAnnotations = [];
        /** Open/close state of comment sections by annotation ID */
        openComments = {};
        /** CSS for the sidebar — lives inside Shadow DOM, zero conflicts */
        getStyles() {
          return `
      .scholic-sidebar {
        position: fixed;
        top: 0;
        right: 0;
        width: 480px;
        height: 100vh;
        background: #141414;
        border-left: 1px solid rgba(255,255,255,0.08);
        color: #e0e0e0;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 13px;
        overflow: hidden;
        transform: translateX(100%);
        transition: transform 0.25s ease;
        pointer-events: auto;
        box-shadow: -4px 0 20px rgba(0,0,0,0.3);
      }

      /* Hide scrollbars for everything inside the sidebar's shadow DOM */
      * {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }

      *::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }

      /* Explicitly target the list container to be sure */
      .sidebar-list-container {
        flex: 1;
        min-height: 0;
        overflow-y: auto;
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      .sidebar-list-container::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }

      .scholic-sidebar.open {
        transform: translateX(0);
      }

      .scholic-sidebar.peek {
        transform: translateX(calc(100% - 32px));
        cursor: pointer;
      }
      .scholic-sidebar.peek:hover {
        transform: translateX(calc(100% - 38px));
      }
      .scholic-sidebar.peek .sidebar-main-content {
        opacity: 0;
        pointer-events: none;
      }

      .peek-indicator {
        position: relative;
        width: 32px;
        flex-shrink: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #1a1a1a;
        border-right: 1px solid rgba(110,183,129,0.2);
        z-index: 10;
        cursor: pointer;
      }
      .scholic-sidebar.open .peek-indicator {
        display: flex;
        cursor: pointer;
        opacity: 0.2;
        transition: opacity 0.2s;
      }
      .scholic-sidebar.open .peek-indicator:hover {
        opacity: 1;
        background: rgba(110,183,129,0.1);
      }
      .scholic-sidebar.open .peek-indicator svg {
        transform: rotate(0deg);
      }
      .peek-indicator svg {
        transform: rotate(180deg);
        color: #6EB781;
        opacity: 0.6;
      }

      /* Header */
      .sidebar-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 16px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
      }

      .sidebar-title {
        font-weight: 700;
        font-size: 15px;
        color: #6EB781;
        text-transform: lowercase;
      }

      .sidebar-close {
        background: none;
        border: none;
        color: #666;
        cursor: pointer;
        font-size: 18px;
        padding: 4px;
        line-height: 1;
      }
      .sidebar-close:hover { color: #fff; }

      /* Tabs */
      .sidebar-tabs {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
        background: rgba(255,255,255,0.015);
      }
      .tab-btn {
        background: transparent;
        border: none;
        color: #888;
        font-size: 13px;
        font-family: inherit;
        font-weight: 500;
        cursor: pointer;
        padding: 5px 12px;
        border-radius: 6px;
        transition: all 0.2s;
      }
      .tab-btn:hover {
        background: rgba(255,255,255,0.05);
        color: #ddd;
      }
      .tab-btn.active {
        background: rgba(110,183,129,0.15);
        color: #6EB781;
        font-weight: 600;
        box-shadow: inset 0 0 0 1px rgba(110,183,129,0.3);
      }
      .refresh-btn {
        margin-left: auto;
        background: transparent;
        border: none;
        color: #888;
        cursor: pointer;
        padding: 5px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.2s, background 0.2s;
      }
      .refresh-btn svg {
        width: 15px;
        height: 15px;
        transition: transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .refresh-btn:hover {
        color: #fff;
        background: rgba(255,255,255,0.05);
      }
      .refresh-btn.spinning svg {
        transform: rotate(360deg);
      }

      /* User Profile */
      .user-profile {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .user-avatar {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(110,183,129,0.3), rgba(71,163,232,0.3));
        border: 1px solid rgba(255,255,255,0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        color: #fff;
        font-weight: 700;
        cursor: pointer;
        transition: transform 0.2s;
        overflow: hidden;
      }
      .user-avatar:hover {
        transform: scale(1.05);
      }

      /* Custom Scrollbar */
      ::-webkit-scrollbar { width: 8px; height: 8px; }
      ::-webkit-scrollbar-track { background: transparent; }
      ::-webkit-scrollbar-thumb { background: #444; border-radius: 4px; }
      ::-webkit-scrollbar-thumb:hover { background: #555; }

      .user-menu {
        position: absolute;
        top: 50px;
        right: 20px;
        background: #1a1a1a;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 8px;
        padding: 6px;
        display: none;
        flex-direction: column;
        z-index: 100;
        box-shadow: 0 8px 24px rgba(0,0,0,0.5);
        min-width: 120px;
      }
      .user-menu.show {
        display: flex;
      }

      .menu-item {
        padding: 8px 12px;
        font-size: 12px;
        color: #888;
        cursor: pointer;
        border-radius: 6px;
        transition: all 0.15s;
        text-align: left;
        background: none;
        border: none;
        width: 100%;
        font-family: inherit;
      }
      .menu-item:hover {
        background: rgba(255,95,87,0.1);
        color: #ff5f57;
      }

      .user-email {
        padding: 8px 12px;
        font-size: 11px;
        color: #555;
        border-bottom: 1px solid rgba(255,255,255,0.05);
        margin-bottom: 4px;
        word-break: break-all;
      }

      /* Annotation form */
      .annotation-form {
        padding: 16px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
      }

      .form-label {
        font-size: 11px;
        text-transform: uppercase;
        color: #666;
        margin-bottom: 8px;
        font-weight: 600;
        letter-spacing: 0.5px;
      }

      .quote-preview {
        background: rgba(110,183,129,0.08);
        border-left: 3px solid #6EB781;
        padding: 10px 14px;
        font-size: 13px;
        color: #ccc;
        line-height: 1.5;
        margin-bottom: 12px;
        border-radius: 0 6px 6px 0;
        max-height: 100px;
        overflow-y: auto;
      }

      .note-input {
        width: 100%;
        min-height: 80px;
        background: #1a1a1a;
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 8px;
        padding: 10px 14px;
        color: #e0e0e0;
        font-size: 13px;
        font-family: inherit;
        resize: vertical;
        margin-bottom: 12px;
        box-sizing: border-box;
      }
      .note-input:focus {
        outline: none;
        border-color: #6EB781;
      }
      .note-input::placeholder { color: #555; }

      /* Color swatches */
      .color-swatches {
        display: flex;
        gap: 8px;
        margin-bottom: 14px;
      }
      .color-swatch {
        width: 22px;
        height: 22px;
        border-radius: 50%;
        border: 2px solid transparent;
        cursor: pointer;
        padding: 0;
        transition: transform 0.15s, border-color 0.15s;
        flex-shrink: 0;
      }
      .color-swatch:hover { transform: scale(1.18); }
      .color-swatch.active {
        border-color: rgba(255,255,255,0.8);
        transform: scale(1.12);
      }

      /* Privacy toggle */
      .privacy-toggle {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 14px;
        padding: 8px 12px;
        background: rgba(255,255,255,0.03);
        border-radius: 8px;
      }
      .privacy-toggle-label {
        font-size: 12px;
        color: #999;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .privacy-toggle-label svg {
        opacity: 0.7;
      }
      .toggle-switch {
        position: relative;
        width: 36px;
        height: 20px;
        background: rgba(110,183,129,0.3);
        border-radius: 10px;
        cursor: pointer;
        transition: background 0.2s;
        flex-shrink: 0;
      }
      .toggle-switch.private {
        background: rgba(232,197,71,0.3);
      }
      .toggle-knob {
        position: absolute;
        top: 2px;
        left: 2px;
        width: 16px;
        height: 16px;
        background: #6EB781;
        border-radius: 50%;
        transition: all 0.2s;
      }
      .toggle-switch.private .toggle-knob {
        left: 18px;
        background: #e8c547;
      }

      .form-actions {
        display: flex;
        gap: 8px;
        justify-content: flex-end;
      }

      .btn {
        padding: 6px 16px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        border: none;
        font-family: inherit;
        transition: all 0.15s;
      }
      .btn-primary {
        background: #6EB781;
        color: #fff;
      }
      .btn-primary:hover { background: #5da870; }
      .btn-secondary {
        background: transparent;
        color: #999;
        border: 1px solid rgba(255,255,255,0.1);
      }
      .btn-secondary:hover { background: rgba(255,255,255,0.04); }

      /* Annotation list */
      .annotation-list {
        padding: 12px 0;
      }

      .annotation-item {
        padding: 14px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.04);
        cursor: pointer;
        transition: background 0.15s;
      }
      .annotation-item:hover {
        background: rgba(255,255,255,0.03);
      }
      .annotation-item.pending {
        opacity: 0.55;
        pointer-events: none;
      }
      .annotation-item.pending::after {
        content: 'Saving\u2026';
        display: block;
        font-size: 10px;
        color: #6EB781;
        margin-top: 4px;
      }

      .load-more-btn {
        display: block;
        width: calc(100% - 40px);
        margin: 12px 20px 16px;
        padding: 9px;
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 8px;
        color: #888;
        font-size: 12px;
        font-family: inherit;
        font-weight: 500;
        cursor: pointer;
        transition: background 0.15s, color 0.15s;
        text-align: center;
      }
      .load-more-btn:hover {
        background: rgba(255,255,255,0.07);
        color: #ccc;
      }

      .annotation-item-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 8px;
      }

      .annotation-author-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 6px;
      }

      .annotation-author-avatar {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(110,183,129,0.3), rgba(71,163,232,0.3));
        font-size: 9px;
        font-weight: 700;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
      }

      .annotation-author-name {
        font-size: 12px;
        font-weight: 600;
        color: #ccc;
        text-decoration: none;
      }
      .annotation-author-name:hover {
        color: #6EB781;
        text-decoration: underline;
      }

      .annotation-quote {
        font-size: 12px;
        color: #ccc;
        line-height: 1.6;
        margin-bottom: 6px;
        font-style: italic;
        display: -webkit-box;
        -webkit-line-clamp: 5;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      .annotation-quote mark {
        background: inherit;
        color: inherit;
        border-radius: 2px;
        padding: 1px 0;
      }

      .annotation-note {
        font-size: 13px;
        color: #ccc;
        line-height: 1.5;
        margin-top: 6px;
        word-break: break-word;
      }

      .annotation-meta {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 11px;
        color: #555;
        margin-top: 8px;
      }

      .annotation-meta svg {
        opacity: 0.6;
      }

      .meta-badge {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 6px;
        border-radius: 4px;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.3px;
      }
      .meta-badge.public {
        background: rgba(110,183,129,0.1);
        color: #6EB781;
      }
      .meta-badge.private {
        background: rgba(232,197,71,0.1);
        color: #e8c547;
      }

      .annotation-delete, .annotation-view {
        background: none;
        border: none;
        color: #444;
        cursor: pointer;
        padding: 4px 6px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        transition: all 0.15s;
      }
      .annotation-delete:hover {
        color: #ff5f57;
        background: rgba(255,95,87,0.1);
      }
      .annotation-view:hover {
        color: #6EB781;
        background: rgba(110,183,129,0.1);
      }
      .annotation-item-actions {
        display: flex;
        align-items: center;
        gap: 2px;
      }

      .annotation-comments {
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid rgba(255,255,255,0.04);
      }

      .annotation-comments-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-bottom: 10px;
      }

      .comment-item {
        background: rgba(255,255,255,0.03);
        border-radius: 6px;
        padding: 6px 10px;
        font-size: 12px;
        line-height: 1.4;
      }
      .comment-item strong {
        color: #ccc;
        margin-right: 6px;
      }
      .comment-item span {
        color: #999;
      }

      .sidebar-reply-input {
        width: 100%;
        padding: 6px 10px;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 6px;
        color: #ccc;
        font-size: 11px;
        font-family: inherit;
        box-sizing: border-box;
        outline: none;
        transition: border-color 0.15s;
      }
      .sidebar-reply-input:focus {
        border-color: rgba(110,183,129,0.4);
      }
      .sidebar-reply-input::placeholder {
        color: #555;
      }

      .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #555;
      }
      .empty-state svg {
        margin-bottom: 12px;
        opacity: 0.3;
      }
      .annotation-list-inner {
        padding-bottom: 40px;
      }
      .annotation-author-name {
        display: inline-block;
        max-width: 250px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        vertical-align: middle;
      }
    `;
        }
        /**
         * Open the sidebar with an annotation form pre-filled with the selected quote.
         */
        openWithQuote(quoteText, selectors) {
          if (!this.isAuthenticated) {
            this.open();
            const formContainer = this.panel.querySelector(".sidebar-form-container");
            if (formContainer) {
              formContainer.innerHTML = `
          <div style="padding: 20px; background: rgba(110,183,129,0.1); border-radius: 8px; margin: 16px 20px; border: 1px solid rgba(110,183,129,0.2);">
            <div style="font-weight: 700; color: #fff; margin-bottom: 8px;">Want to save this?</div>
            <div style="font-size: 12px; color: #888; margin-bottom: 12px;">Sign in to save your highlights and join the conversation.</div>
            <button class="btn btn-primary login-btn-inline" style="width: 100%;">Sign in to Scholic</button>
          </div>
        `;
              formContainer.querySelector(".login-btn-inline")?.addEventListener("click", () => {
                const extId = chrome.runtime.id;
                const loginUrl = `${CONFIG.WEB_URL}/auth/extension-login?extId=${extId}`;
                window.open(loginUrl, "_blank");
              });
            }
            return;
          }
          this.pendingQuoteText = quoteText;
          this.pendingSelectors = selectors;
          this.open();
          this.renderForm();
        }
        /**
         * Open the sidebar with an image annotation form.
         */
        openWithImage(imageData) {
          this.open();
          this.renderForm("image", imageData);
        }
        /** Open the sidebar (without a pending annotation) */
        open() {
          this.isOpen = true;
          this.panel.classList.remove("peek");
          this.panel.classList.add("open");
          this.applyBodyShift("480px");
        }
        /** Show the sidebar in a collapsed "peek" state */
        showPeek() {
          this.isOpen = false;
          this.panel.classList.remove("open");
          this.panel.classList.add("peek");
          this.applyBodyShift("32px");
          const peek = this.panel.querySelector(".peek-indicator");
          if (peek) {
            peek.onclick = () => this.isOpen ? this.showPeek() : this.open();
          }
        }
        /** Close the sidebar (goes back to peek if active) */
        close() {
          this.showPeek();
        }
        /** Completely hide the sidebar (inactive state) */
        hideCompletely() {
          this.isOpen = false;
          this.panel.classList.remove("open");
          this.panel.classList.remove("peek");
          this.applyBodyShift("0");
          this.pendingQuoteText = "";
          this.pendingSelectors = [];
        }
        /** Toggle sidebar open/close */
        toggle() {
          this.isOpen ? this.close() : this.open();
        }
        /**
         * Render the annotation creation form inside the sidebar.
         * Shows the quoted text (for text) or image preview (for image), textarea, and a public/private toggle.
         */
        renderForm(type = "text", imageData = "") {
          const container = this.panel.querySelector(".sidebar-form-container");
          if (!container) return;
          container.innerHTML = "";
          let isPrivate = false;
          let selectedColor = HIGHLIGHT_COLORS[0].hex;
          const form = document.createElement("div");
          form.className = "annotation-form";
          let previewHtml = "";
          if (type === "text") {
            previewHtml = `
        <div class="form-label">Selected Text</div>
        <div class="quote-preview">${this.escapeHtml(this.pendingQuoteText)}</div>
      `;
          } else {
            previewHtml = `
        <div class="form-label">Screenshot Preview</div>
        <div class="image-annotation-preview" style="margin-bottom: 12px; border-radius: 6px; overflow: hidden; border: 1px solid rgba(255,255,255,0.1);">
          <img src="${imageData}" style="width: 100%; display: block;" />
        </div>
      `;
          }
          const swatchesHtml = `
      <div class="form-label">Highlight Color</div>
      <div class="color-swatches">
        ${HIGHLIGHT_COLORS.map((c, i) => `
          <button class="color-swatch${i === 0 ? " active" : ""}" data-color="${c.hex}" style="background:${c.hex}" title="${c.name}"></button>
        `).join("")}
      </div>
    `;
          form.innerHTML = `
      ${previewHtml}
      <div class="form-label">Your Note</div>
      <textarea class="note-input" placeholder="Add your thoughts..." maxlength="5000"></textarea>
      ${type === "text" ? swatchesHtml : ""}
      <div class="privacy-toggle">
        <div class="toggle-switch" id="privacy-switch">
          <div class="toggle-knob"></div>
        </div>
        <div class="privacy-toggle-label" id="privacy-label">
          ${ICONS.globe}
          <span>Public</span>
        </div>
      </div>
      <div class="form-actions">
        <button class="btn btn-secondary cancel-btn">Cancel</button>
        <button class="btn btn-primary save-btn">Save</button>
      </div>
    `;
          container.appendChild(form);
          const textarea = form.querySelector(".note-input");
          setTimeout(() => textarea?.focus(), 100);
          const toggle = form.querySelector("#privacy-switch");
          const label = form.querySelector("#privacy-label");
          toggle?.addEventListener("click", () => {
            isPrivate = !isPrivate;
            toggle.classList.toggle("private", isPrivate);
            label.innerHTML = isPrivate ? `${ICONS.lock}<span>Private</span>` : `${ICONS.globe}<span>Public</span>`;
          });
          form.querySelectorAll(".color-swatch").forEach((btn) => {
            btn.addEventListener("click", () => {
              form.querySelectorAll(".color-swatch").forEach((b) => b.classList.remove("active"));
              btn.classList.add("active");
              selectedColor = btn.dataset.color || HIGHLIGHT_COLORS[0].hex;
            });
          });
          form.querySelector(".cancel-btn")?.addEventListener("click", () => {
            form.remove();
            this.pendingQuoteText = "";
            this.pendingSelectors = [];
          });
          form.querySelector(".save-btn")?.addEventListener("click", () => {
            const note = textarea?.value || "";
            this.callbacks.onSave({
              url: window.location.href,
              quoteText: type === "text" ? this.pendingQuoteText : "Screenshot",
              text: note,
              selectors: type === "text" ? this.pendingSelectors : [],
              isPrivate,
              type,
              image: type === "image" ? imageData : void 0,
              highlightColor: selectedColor
            });
            form.remove();
            this.pendingQuoteText = "";
            this.pendingSelectors = [];
          });
        }
        /**
         * Render the list of existing annotations in the sidebar.
         * Guarded against concurrent/duplicate renders.
         */
        async renderAnnotationList(annotations, hasMore = false) {
          if (this.isRendering) return;
          this.isRendering = true;
          try {
            this.lastAnnotations = annotations;
            this.renderHeader();
            const listContainer = this.panel.querySelector(".sidebar-list-container");
            if (!listContainer) return;
            listContainer.innerHTML = "";
            if (!this.isAuthenticated) {
              const banner = document.createElement("div");
              banner.style.cssText = `
          padding: 12px 20px;
          background: #6EB781;
          color: #0a0a0a;
          font-size: 12px;
          font-weight: 600;
          display: flex;
          align-items: center;
          justify-content: space-between;
          position: sticky;
          top: 0;
          z-index: 10;
          box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        `;
              banner.innerHTML = `
          <span>Sign in to save highlights and comment</span>
          <button class="banner-login-btn" style="background:rgba(0,0,0,0.1); border:1px solid rgba(0,0,0,0.2); border-radius:4px; padding:4px 10px; font-size:11px; font-weight:700; cursor:pointer;">Sign In</button>
        `;
              banner.querySelector(".banner-login-btn")?.addEventListener("click", () => {
                const extId = chrome.runtime.id;
                const loginUrl = `${CONFIG.WEB_URL}/auth/extension-login?extId=${extId}`;
                window.open(loginUrl, "_blank");
              });
              listContainer.appendChild(banner);
            }
            const list = document.createElement("div");
            list.className = "annotation-list-inner";
            listContainer.appendChild(list);
            const myUserId = this.userData?.id;
            let displayAnnotations = this.isAuthenticated ? annotations : annotations.filter((a) => !a.isPrivate);
            if (this.activeTab === "mine") {
              displayAnnotations = displayAnnotations.filter((a) => String(a.userId) === String(myUserId));
            } else if (this.activeTab === "community") {
              displayAnnotations = displayAnnotations.filter((a) => String(a.userId) !== String(myUserId));
            }
            if (displayAnnotations.length === 0) {
              let msg = this.activeTab === "mine" ? "You haven't made any highlights here yet." : this.activeTab === "community" ? "No one else has annotated this page yet." : "No annotations on this page yet.";
              list.innerHTML = `
          <div class="empty-state">
            ${ICONS.pen}
            <div style="font-weight:600; margin-bottom:8px; color:#ddd;">Nothing to see</div>
            <div style="font-size:12px; line-height:1.5;">${msg}<br/>Select some text to get started.</div>
          </div>
        `;
            } else {
              displayAnnotations.forEach((annotation) => {
                const item = document.createElement("div");
                item.className = annotation._isPending ? "annotation-item pending" : "annotation-item";
                const privacyBadge = annotation.isPrivate ? `<span class="meta-badge private">${ICONS.lock} Only you</span>` : `<span class="meta-badge public">${ICONS.globe} Public</span>`;
                const timeStr = annotation.createdAt ? timeAgo(annotation.createdAt) : "";
                const authorName = annotation.user?.username || annotation.user?.email?.split("@")[0] || "Unknown";
                const authorInitial = authorName[0].toUpperCase();
                const avatarHtml = annotation.user?.profilePicture ? `<img src="${this.escapeAttr(annotation.user.profilePicture)}" style="width:100%; height:100%; object-fit:cover;" />` : authorInitial;
                item.innerHTML = `
            <div class="annotation-item-header">
              ${privacyBadge}
              <div class="annotation-item-actions">
                ${annotation.id ? `<a href="${CONFIG.WEB_URL}/annotation/${annotation.id}" target="_blank" class="annotation-view" title="View annotation"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></a>` : ""}
                ${annotation.id && String(annotation.userId) === String(myUserId) ? `<button class="annotation-delete" data-id="${annotation.id}" title="Delete annotation">${ICONS.trash}</button>` : ""}
              </div>
            </div>
            <div class="annotation-author-row">
              <div class="annotation-author-avatar">${avatarHtml}</div>
              <a href="${CONFIG.WEB_URL}/u/${this.escapeHtml(authorName)}" target="_blank" class="annotation-author-name">
                @${this.escapeHtml(authorName)}
              </a>
            </div>
            ${annotation.type === "image" && annotation.imageUrl ? `
              <div class="annotation-image" style="margin-bottom: 8px; border-radius: 6px; overflow: hidden; border: 1px solid rgba(255,255,255,0.1);">
                <img src="${this.escapeAttr(annotation.imageUrl || "")}" style="width: 100%; display: block;" />
              </div>
            ` : `<div class="annotation-quote"><mark style="background:${this.hexToRgba(annotation.highlightColor || "#A8D5B5", 0.12)}">${this.escapeHtml(annotation.quoteText)}</mark></div>`}
            ${annotation.id ? `
              <div class="annotation-note" data-id="${annotation.id}">
                ${(() => {
                  const text = annotation.text || "";
                  const words = text.split(/\s+/);
                  if (words.length <= 60) return this.escapeHtml(text);
                  return `
                    <span class="note-text">${this.escapeHtml(words.slice(0, 60).join(" "))}...</span>
                    <button class="read-more-btn" style="background:none; border:none; color:#6EB781; font-size:11px; font-weight:600; cursor:pointer; padding:0; margin-left:4px; font-family:inherit;">Read more</button>
                  `;
                })()}
              </div>
            ` : ""}
            <div class="annotation-meta">
              ${timeStr ? `<span>${timeStr}</span>` : ""}
              ${annotation.id ? `
                <button class="toggle-comments-btn" data-id="${annotation.id}" style="background:none; border:none; color:#555; cursor:pointer; font-size:12px; margin-left:12px; display:flex; align-items:center; gap:4px; padding:0;">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                  </svg>
                  <span>${annotation.comments?.length || 0}</span>
                </button>
              ` : ""}
            </div>
            ${annotation.id && this.openComments[annotation.id] ? `
              <div class="annotation-comments">
                ${this.isAuthenticated ? `
                  <input type="text" class="sidebar-reply-input" data-id="${annotation.id}" placeholder="Add a comment..." style="margin-bottom: 12px;" />
                ` : `
                  <div style="background: rgba(255,255,255,0.03); border: 1px dashed rgba(255,255,255,0.1); border-radius: 6px; padding: 10px; font-size: 11px; color: #666; text-align: center; margin-bottom: 12px;">
                    Sign in to join the conversation
                  </div>
                `}
                ${annotation.comments && annotation.comments.length > 0 ? `
                  <div class="annotation-comments-list">
                    ${annotation.comments.map((c) => {
                  const cname = c.user?.username || c.user?.emailSlice || "User";
                  const cinit = cname[0].toUpperCase();
                  const cavatar = c.user?.profilePicture ? `<img src="${this.escapeAttr(c.user.profilePicture)}" style="width:100%; height:100%; object-fit:cover;" />` : cinit;
                  return `
                        <div class="comment-item" style="display:flex; gap:8px; align-items:flex-start; margin-bottom:6px; background:rgba(255,255,255,0.02); padding:8px 10px; border-radius:6px;">
                          <div style="width:20px; height:20px; border-radius:50%; background:linear-gradient(135deg, rgba(110,183,129,0.3), rgba(71,163,232,0.3)); font-size:9px; font-weight:700; color:#fff; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                            ${cavatar}
                          </div>
                          <div style="flex:1; font-size:12px; line-height:1.4; padding-top:2px;">
                            <a href="${CONFIG.WEB_URL}/u/${this.escapeHtml(cname)}" target="_blank" style="text-decoration:none; color:inherit;">
                              <strong style="color:#d0d0d0; display:block; margin-bottom:2px;">@${this.escapeHtml(cname)}</strong>
                            </a>
                            <span style="color:#aaa;">${this.escapeHtml(c.text)}</span>
                          </div>
                        </div>
                      `;
                }).join("")}
                  </div>
                ` : ""}
              </div>
              ` : ""}
          `;
                const readMoreBtn = item.querySelector(".read-more-btn");
                if (readMoreBtn) {
                  let currentLimit = 60;
                  readMoreBtn.addEventListener("click", (e) => {
                    e.stopPropagation();
                    const noteTextEl = item.querySelector(".note-text");
                    if (!noteTextEl) return;
                    const fullText = annotation.text || "";
                    const words = fullText.split(/\s+/);
                    currentLimit += 120;
                    if (currentLimit >= words.length) {
                      noteTextEl.textContent = fullText;
                      readMoreBtn.remove();
                    } else {
                      noteTextEl.textContent = words.slice(0, currentLimit).join(" ") + "...";
                    }
                  });
                }
                item.addEventListener("click", (e) => {
                  if (e.target.closest(".annotation-delete") || e.target.closest(".annotation-view")) {
                    return;
                  }
                  if (annotation.id) {
                    this.callbacks.onFocusAnnotation(annotation.id);
                  }
                });
                const toggleBtn = item.querySelector(".toggle-comments-btn");
                toggleBtn?.addEventListener("click", (e) => {
                  e.stopPropagation();
                  if (annotation.id) {
                    this.openComments[annotation.id] = !this.openComments[annotation.id];
                    setTimeout(() => {
                      this.isRendering = false;
                      this.renderAnnotationList(this.lastAnnotations);
                    }, 0);
                  }
                });
                const deleteBtn = item.querySelector(".annotation-delete");
                deleteBtn?.addEventListener("click", (e) => {
                  e.stopPropagation();
                  const id = e.currentTarget.dataset.id;
                  if (id && confirm("Delete this annotation? This cannot be undone.")) {
                    this.callbacks.onDelete(id);
                  }
                });
                const replyInput = item.querySelector(".sidebar-reply-input");
                replyInput?.addEventListener("keydown", (e) => {
                  if (e.key === "Enter") {
                    const text = replyInput.value.trim();
                    if (text && annotation.id) {
                      replyInput.disabled = true;
                      this.callbacks.onComment(annotation.id, text).finally(() => {
                        replyInput.disabled = false;
                        replyInput.value = "";
                      });
                    }
                  }
                });
                replyInput?.addEventListener("click", (e) => e.stopPropagation());
                list.appendChild(item);
              });
            }
            if (hasMore && this.callbacks.onLoadMore) {
              const loadMoreBtn = document.createElement("button");
              loadMoreBtn.className = "load-more-btn";
              loadMoreBtn.textContent = "Load more";
              loadMoreBtn.addEventListener("click", () => {
                this.callbacks.onLoadMore?.();
              });
              listContainer.appendChild(loadMoreBtn);
            }
            const contentLayer = this.panel.querySelector(".sidebar-content");
            if (contentLayer) contentLayer.scrollTop = 0;
          } finally {
            this.isRendering = false;
          }
        }
        /** Escape a value for safe use inside an HTML attribute (e.g. src="...") */
        escapeAttr(value) {
          return (value || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }
        hexToRgba(hex, alpha) {
          const h = hex && hex.startsWith("#") && hex.length === 7 ? hex : "#A8D5B5";
          const r = parseInt(h.slice(1, 3), 16);
          const g = parseInt(h.slice(3, 5), 16);
          const b = parseInt(h.slice(5, 7), 16);
          return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }
        /** Simple HTML escaping to prevent XSS in displayed text */
        escapeHtml(text) {
          const div = document.createElement("div");
          div.textContent = text;
          return div.innerHTML;
        }
        /**
         * Shift the page body to make room for the sidebar.
         */
        applyBodyShift(width) {
          document.body.style.transition = "margin-right 0.25s ease";
          document.body.style.marginRight = width;
        }
        /** Clean up: remove the sidebar from the DOM */
        destroy() {
          this.hideCompletely();
          if (this.host.parentNode) {
            this.host.parentNode.removeChild(this.host);
          }
        }
      };
    }
  });

  // src/highlight-popup.ts
  var HighlightPopup;
  var init_highlight_popup = __esm({
    "src/highlight-popup.ts"() {
      "use strict";
      init_config();
      HighlightPopup = class {
        host = null;
        shadow = null;
        currentAnnotationId = null;
        currentHighlightEl = null;
        commentsOpen = false;
        getAnnotation;
        hideTimer = null;
        onComment;
        constructor(getAnnotation, onComment) {
          this.getAnnotation = getAnnotation;
          this.onComment = onComment;
        }
        show(annotationId, highlightEl, force = false) {
          if (!force && this.currentAnnotationId === annotationId && this.host) {
            this.cancelHide();
            return;
          }
          this.commentsOpen = false;
          const annotation = this.getAnnotation(annotationId);
          if (!annotation) return;
          this.hideImmediately();
          this.currentAnnotationId = annotationId;
          this.currentHighlightEl = highlightEl;
          this.host = document.createElement("scholic-popup-host");
          this.host.style.cssText = "position: absolute; z-index: 2147483646;";
          this.shadow = this.host.attachShadow({ mode: "closed" });
          const style = document.createElement("style");
          style.textContent = this.getStyles();
          this.shadow.appendChild(style);
          const authorName = annotation.user?.username || annotation.user?.email || "You";
          const initial = authorName[0].toUpperCase();
          const avatarHtml = annotation.user?.profilePicture ? `<img src="${annotation.user.profilePicture}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;" />` : this.escapeHtml(initial);
          const noteText = annotation.text || "";
          const commentCount = annotation.comments?.length || 0;
          const extLinkSvg = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`;
          const msgSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`;
          const sendSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`;
          const commentsItemsHtml = (annotation.comments || []).map((c) => {
            const cname = c.user?.username || c.user?.email?.split("@")[0] || "User";
            const cavatar = c.user?.profilePicture ? `<img src="${c.user.profilePicture}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;" />` : this.escapeHtml(cname[0].toUpperCase());
            return `
        <div class="popup-comment-item">
          <div class="popup-comment-avatar">${cavatar}</div>
          <div class="popup-comment-content">
            <span class="popup-comment-author">@${this.escapeHtml(cname)}</span>
            <span class="popup-comment-text">${this.escapeHtml(c.text)}</span>
          </div>
        </div>`;
          }).join("");
          const popup = document.createElement("div");
          popup.className = "scholic-popup";
          popup.innerHTML = `
      <div class="popup-header">
        <a href="${CONFIG.WEB_URL}/u/${this.escapeAttr(authorName)}" target="_blank" class="popup-author-link">
          <div class="popup-avatar">${avatarHtml}</div>
          <span class="popup-author">@${this.escapeHtml(authorName)}</span>
        </a>
        <div class="popup-header-right">
          <span class="popup-badge ${annotation.isPrivate ? "badge-private" : "badge-public"}">
            ${annotation.isPrivate ? "Private" : "Public"}
          </span>
          ${annotation.id ? `<a href="${CONFIG.WEB_URL}/annotation/${annotation.id}" target="_blank" class="popup-view-link" title="View annotation">${extLinkSvg}</a>` : ""}
        </div>
      </div>

      ${noteText ? `
        <div class="popup-note">
          ${(() => {
            const words = noteText.split(/\s+/);
            if (words.length <= 60) return this.escapeHtml(noteText);
            return `
              <span class="note-text">${this.escapeHtml(words.slice(0, 60).join(" "))}...</span>
              <button class="read-more-btn" style="background:none; border:none; color:#6EB781; font-size:11px; font-weight:600; cursor:pointer; padding:0; margin-left:4px; font-family:inherit;">Read more</button>
            `;
          })()}
        </div>
      ` : ""}

      <div class="popup-actions">
        <button class="popup-toggle-comments">
          ${msgSvg}
          <span class="comment-count">${commentCount}</span>
        </button>
      </div>

      <div class="popup-comments-drawer">
        ${commentsItemsHtml ? `<div class="popup-comments-list">${commentsItemsHtml}</div>` : ""}
        <div class="popup-reply-section">
          <div class="popup-reply-wrap">
            <input type="text" class="popup-reply-input" placeholder="Add a reply\u2026" />
            <button class="popup-send-btn">${sendSvg}</button>
          </div>
        </div>
      </div>
    `;
          const toggleBtn = popup.querySelector(".popup-toggle-comments");
          const drawer = popup.querySelector(".popup-comments-drawer");
          const replyInput = popup.querySelector(".popup-reply-input");
          const sendBtn = popup.querySelector(".popup-send-btn");
          const readMoreBtn = popup.querySelector(".read-more-btn");
          if (readMoreBtn) {
            let currentLimit = 60;
            readMoreBtn.addEventListener("click", (e) => {
              e.stopPropagation();
              const noteTextEl = popup.querySelector(".note-text");
              if (!noteTextEl) return;
              const words = noteText.split(/\s+/);
              currentLimit += 120;
              if (currentLimit >= words.length) {
                noteTextEl.textContent = noteText;
                readMoreBtn.remove();
              } else {
                noteTextEl.textContent = words.slice(0, currentLimit).join(" ") + "...";
              }
              if (this.host) {
                this.host.style.top = "-10000px";
                setTimeout(() => {
                  if (!this.host || !this.host.parentNode) return;
                  const rect2 = highlightEl.getBoundingClientRect();
                  const pHeight = popup.offsetHeight;
                  this.host.style.top = rect2.top < pHeight + 16 ? `${rect2.bottom + window.scrollY + 8}px` : `${rect2.top + window.scrollY - pHeight - 8}px`;
                }, 0);
              }
            });
          }
          this.host.addEventListener("mouseenter", () => this.cancelHide());
          this.host.addEventListener("mouseleave", () => this.scheduleHide());
          toggleBtn?.addEventListener("click", (e) => {
            e.stopPropagation();
            this.commentsOpen = !this.commentsOpen;
            toggleBtn.classList.toggle("active", this.commentsOpen);
            drawer.classList.toggle("open", this.commentsOpen);
            if (this.commentsOpen) {
              setTimeout(() => replyInput?.focus(), 220);
            }
          });
          const submitReply = () => {
            const text = replyInput?.value.trim();
            if (!text || !annotationId) return;
            replyInput.disabled = true;
            sendBtn.classList.add("sending");
            sendBtn.classList.remove("has-text");
            this.onComment(annotationId, text).then(() => {
              const updated = this.getAnnotation(annotationId);
              const newComment = updated?.comments?.[updated.comments.length - 1];
              if (newComment) {
                let list = drawer.querySelector(".popup-comments-list");
                if (!list) {
                  list = document.createElement("div");
                  list.className = "popup-comments-list";
                  drawer.insertBefore(list, drawer.querySelector(".popup-reply-section"));
                }
                const cname = newComment.user?.username || newComment.user?.email?.split("@")[0] || "User";
                const cavatar = newComment.user?.profilePicture ? `<img src="${newComment.user.profilePicture}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;" />` : this.escapeHtml(cname[0].toUpperCase());
                const item = document.createElement("div");
                item.className = "popup-comment-item popup-comment-item--new";
                item.innerHTML = `
            <div class="popup-comment-avatar">${cavatar}</div>
            <div class="popup-comment-content">
              <span class="popup-comment-author">@${this.escapeHtml(cname)}</span>
              <span class="popup-comment-text">${this.escapeHtml(newComment.text)}</span>
            </div>`;
                list.appendChild(item);
                const countEl = popup.querySelector(".comment-count");
                if (countEl) countEl.textContent = String(updated?.comments?.length ?? 1);
              }
            }).finally(() => {
              replyInput.disabled = false;
              replyInput.value = "";
              sendBtn.classList.remove("sending");
            });
          };
          replyInput?.addEventListener("keydown", (e) => {
            e.stopPropagation();
            if (e.key === "Enter") {
              e.preventDefault();
              submitReply();
            }
          });
          replyInput?.addEventListener("input", () => {
            sendBtn?.classList.toggle("has-text", !!replyInput.value.trim());
          });
          sendBtn?.addEventListener("click", submitReply);
          this.shadow.appendChild(popup);
          const rect = highlightEl.getBoundingClientRect();
          const scrollX = window.scrollX;
          const scrollY = window.scrollY;
          const popupWidth = 288;
          let left = rect.left + scrollX + rect.width / 2 - popupWidth / 2;
          left = Math.max(8, Math.min(left, window.innerWidth - popupWidth - 8 + scrollX));
          this.host.style.left = `${left}px`;
          this.host.style.top = "-10000px";
          document.body.appendChild(this.host);
          const popupHeight = popup.offsetHeight;
          this.host.style.top = rect.top < popupHeight + 16 ? `${rect.bottom + scrollY + 8}px` : `${rect.top + scrollY - popupHeight - 8}px`;
        }
        /** Kept for external callers; no longer causes a full re-render. */
        refresh() {
          if (this.currentAnnotationId && this.currentHighlightEl) {
            this.show(this.currentAnnotationId, this.currentHighlightEl);
          }
        }
        scheduleHide() {
          this.cancelHide();
          this.hideTimer = window.setTimeout(() => this.hideImmediately(), 300);
        }
        cancelHide() {
          if (this.hideTimer !== null) {
            clearTimeout(this.hideTimer);
            this.hideTimer = null;
          }
        }
        hideImmediately() {
          this.cancelHide();
          if (this.host?.parentNode) this.host.parentNode.removeChild(this.host);
          this.host = null;
          this.shadow = null;
          this.currentAnnotationId = null;
          this.commentsOpen = false;
        }
        escapeHtml(text) {
          const div = document.createElement("div");
          div.textContent = text;
          return div.innerHTML;
        }
        escapeAttr(value) {
          return (value || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
        }
        getStyles() {
          return `
      * { box-sizing: border-box; margin: 0; padding: 0; }

      .scholic-popup {
        width: 288px;
        background: #111;
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 14px;
        box-shadow:
          0 2px 4px rgba(0,0,0,0.3),
          0 12px 40px rgba(0,0,0,0.6),
          inset 0 1px 0 rgba(255,255,255,0.04);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        color: #e0e0e0;
        overflow: hidden;
        animation: popup-in 0.18s cubic-bezier(0.22, 1, 0.36, 1) both;
      }

      @keyframes popup-in {
        from { opacity: 0; transform: translateY(6px) scale(0.96); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
      }

      .popup-header {
        display: flex;
        align-items: center;
        gap: 9px;
        padding: 13px 14px 10px;
      }

      .popup-author-link {
        display: flex;
        align-items: center;
        gap: 8px;
        text-decoration: none;
        min-width: 0;
        flex: 1;
      }
      .popup-author-link:hover .popup-author { color: #6EB781; }

      .popup-header-right {
        display: flex;
        align-items: center;
        gap: 7px;
        flex-shrink: 0;
      }

      .popup-view-link {
        display: flex;
        align-items: center;
        color: #555;
        text-decoration: none;
        transition: color 0.15s;
      }
      .popup-view-link:hover { color: #6EB781; }

      .popup-avatar {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(110,183,129,0.45), rgba(71,163,232,0.45));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        font-weight: 700;
        color: #fff;
        flex-shrink: 0;
        overflow: hidden;
      }

      .popup-author {
        font-size: 12px;
        font-weight: 600;
        color: #ddd;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        transition: color 0.15s;
      }

      .popup-badge {
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        padding: 2px 6px;
        border-radius: 4px;
        flex-shrink: 0;
      }
      .badge-public  { background: rgba(110,183,129,0.12); color: #6EB781; border: 1px solid rgba(110,183,129,0.2); }
      .badge-private { background: rgba(232,71,122,0.1);   color: #E8477A; border: 1px solid rgba(232,71,122,0.18); }

      .popup-note {
        padding: 0 14px 12px;
        font-size: 12px;
        color: #999;
        line-height: 1.6;
        border-bottom: 1px solid rgba(255,255,255,0.05);
      }

      .popup-actions {
        padding: 8px 14px;
        display: flex;
        align-items: center;
      }

      .popup-toggle-comments {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        background: none;
        border: none;
        cursor: pointer;
        color: #555;
        font-size: 12px;
        font-family: inherit;
        padding: 3px 0;
        transition: color 0.15s;
        line-height: 1;
      }
      .popup-toggle-comments:hover { color: #999; }
      .popup-toggle-comments.active { color: #6EB781; }

      /* Drawer: animates open/closed with max-height */
      .popup-comments-drawer {
        max-height: 0;
        overflow: hidden;
        opacity: 0;
        border-top: 1px solid transparent;
        transition: max-height 0.25s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.16s ease, border-top-color 0.16s ease;
        display: flex;
        flex-direction: column;
      }
      .popup-comments-drawer.open {
        max-height: 400px;
        opacity: 1;
        border-top-color: rgba(255,255,255,0.05);
      }

      .popup-comments-list {
        max-height: 200px;
        overflow-y: auto;
        padding: 8px 10px 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }

      .popup-comments-list::-webkit-scrollbar { width: 3px; }
      .popup-comments-list::-webkit-scrollbar-track { background: transparent; }
      .popup-comments-list::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.12);
        border-radius: 3px;
      }

      .popup-comment-item {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        padding: 7px 8px;
        border-radius: 8px;
        background: rgba(255,255,255,0.03);
        transition: background 0.12s;
      }
      .popup-comment-item:hover { background: rgba(255,255,255,0.05); }

      /* New comment slides in after posting */
      .popup-comment-item--new {
        animation: comment-in 0.2s cubic-bezier(0.22, 1, 0.36, 1) both;
      }
      @keyframes comment-in {
        from { opacity: 0; transform: translateY(4px); }
        to   { opacity: 1; transform: translateY(0); }
      }

      .popup-comment-avatar {
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: linear-gradient(135deg, rgba(110,183,129,0.35), rgba(71,163,232,0.35));
        font-size: 7px;
        font-weight: 700;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        overflow: hidden;
        margin-top: 1px;
      }

      .popup-comment-content {
        flex: 1;
        min-width: 0;
        font-size: 11px;
        line-height: 1.5;
      }

      .popup-comment-author {
        font-weight: 600;
        color: #bbb;
        margin-right: 5px;
      }

      .popup-comment-text { color: #777; }

      .popup-reply-section {
        padding: 8px 10px 10px;
        border-top: 1px solid rgba(255,255,255,0.05);
      }

      .popup-reply-wrap {
        display: flex;
        align-items: center;
        gap: 6px;
        background: rgba(255,255,255,0.04);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 8px;
        padding: 0 6px 0 10px;
        transition: border-color 0.15s, background 0.15s;
      }
      .popup-reply-wrap:focus-within {
        border-color: rgba(110,183,129,0.35);
        background: rgba(255,255,255,0.06);
      }

      .popup-reply-input {
        flex: 1;
        background: none;
        border: none;
        outline: none;
        font-size: 11px;
        color: #ccc;
        font-family: inherit;
        padding: 8px 0;
      }
      .popup-reply-input::placeholder { color: #444; }
      .popup-reply-input:disabled { opacity: 0.5; }

      .popup-send-btn {
        width: 24px;
        height: 24px;
        border-radius: 6px;
        border: none;
        background: transparent;
        color: #444;
        cursor: default;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        transition: background 0.15s, color 0.15s;
        font-family: inherit;
      }
      .popup-send-btn.has-text {
        background: #6EB781;
        color: #0a0a0a;
        cursor: pointer;
      }
      .popup-send-btn.has-text:hover { filter: brightness(1.1); }
      .popup-send-btn.sending { opacity: 0.5; cursor: default; }
    `;
        }
      };
    }
  });

  // src/snipper.ts
  var Snipper;
  var init_snipper = __esm({
    "src/snipper.ts"() {
      "use strict";
      Snipper = class {
        overlay = null;
        selection = null;
        startX = 0;
        startY = 0;
        onSelect;
        onCancel;
        constructor(onSelect, onCancel) {
          this.onSelect = onSelect;
          this.onCancel = onCancel;
        }
        start() {
          if (this.overlay) return;
          this.overlay = document.createElement("div");
          Object.assign(this.overlay.style, {
            position: "fixed",
            top: "0",
            left: "0",
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.4)",
            zIndex: "2147483647",
            cursor: "crosshair"
          });
          this.selection = document.createElement("div");
          Object.assign(this.selection.style, {
            position: "absolute",
            border: "2px solid #3b82f6",
            backgroundColor: "rgba(59, 130, 246, 0.1)",
            display: "none",
            pointerEvents: "none"
          });
          this.overlay.appendChild(this.selection);
          document.body.appendChild(this.overlay);
          this.overlay.addEventListener("mousedown", this.handleMouseDown);
          this.overlay.addEventListener("keydown", this.handleKeyDown);
          window.addEventListener("mousemove", this.handleMouseMove);
          window.addEventListener("mouseup", this.handleMouseUp);
          this.overlay.tabIndex = -1;
          this.overlay.focus();
        }
        handleMouseDown = (e) => {
          if (e.button !== 0) return;
          this.startX = e.clientX;
          this.startY = e.clientY;
          if (this.selection) {
            this.selection.style.left = `${this.startX}px`;
            this.selection.style.top = `${this.startY}px`;
            this.selection.style.width = "0px";
            this.selection.style.height = "0px";
            this.selection.style.display = "block";
          }
        };
        handleMouseMove = (e) => {
          if (!this.selection || this.selection.style.display === "none") return;
          const currentX = e.clientX;
          const currentY = e.clientY;
          const width = Math.abs(currentX - this.startX);
          const height = Math.abs(currentY - this.startY);
          const left = Math.min(currentX, this.startX);
          const top = Math.min(currentY, this.startY);
          this.selection.style.width = `${width}px`;
          this.selection.style.height = `${height}px`;
          this.selection.style.left = `${left}px`;
          this.selection.style.top = `${top}px`;
        };
        handleMouseUp = (e) => {
          if (!this.selection || this.selection.style.display === "none") return;
          const width = parseInt(this.selection.style.width);
          const height = parseInt(this.selection.style.height);
          const x = parseInt(this.selection.style.left);
          const y = parseInt(this.selection.style.top);
          this.cleanup();
          if (width > 5 && height > 5) {
            const dpr = window.devicePixelRatio || 1;
            const area = {
              x: x * dpr,
              y: y * dpr,
              width: width * dpr,
              height: height * dpr
            };
            requestAnimationFrame(() => requestAnimationFrame(() => this.onSelect(area)));
          } else {
            this.onCancel();
          }
        };
        handleKeyDown = (e) => {
          if (e.key === "Escape") {
            this.cleanup();
            this.onCancel();
          }
        };
        cleanup() {
          if (this.overlay) {
            this.overlay.removeEventListener("mousedown", this.handleMouseDown);
            this.overlay.removeEventListener("keydown", this.handleKeyDown);
            this.overlay.remove();
            this.overlay = null;
          }
          this.selection = null;
          window.removeEventListener("mousemove", this.handleMouseMove);
          window.removeEventListener("mouseup", this.handleMouseUp);
        }
      };
    }
  });

  // src/content.ts
  var require_content = __commonJS({
    "src/content.ts"() {
      init_anchoring();
      init_highlighter();
      init_popover();
      init_sidebar();
      init_highlight_popup();
      init_snipper();
      var IS_IFRAME = window.self !== window.top;
      var highlightMap = /* @__PURE__ */ new Map();
      var pageAnnotations = [];
      var pendingHighlightElements = [];
      var currentActiveTab = "mine";
      var suppressSync = false;
      var syncInterval = null;
      var syncAttemptsLeft = 0;
      var annotationsTotal = 0;
      var annotationsOffset = 0;
      var ANNOTATIONS_PAGE_SIZE = 50;
      function applyHighlightColor(elements, hex) {
        const color = hex && hex.startsWith("#") && hex.length === 7 ? hex : "#A8D5B5";
        const r = parseInt(color.slice(1, 3), 16);
        const g = parseInt(color.slice(3, 5), 16);
        const b = parseInt(color.slice(5, 7), 16);
        const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        const alpha = luminance >= 0.65 ? 0.3 : luminance >= 0.45 ? 0.2 : luminance >= 0.3 ? 0.14 : 0.1;
        elements.forEach((el) => {
          el.style.setProperty("--sr", String(r));
          el.style.setProperty("--sg", String(g));
          el.style.setProperty("--sb", String(b));
          el.style.setProperty("--sa", String(alpha));
        });
      }
      var popover = new SelectionPopover({
        onAnnotate: (range, quoteText) => handleAnnotate(range, quoteText),
        onHighlight: (range, quoteText) => handleHighlight(range, quoteText)
      });
      var sidebar = new Sidebar({
        onSave: (annotation) => handleSaveAnnotation(annotation),
        onDelete: (annotationId) => handleDeleteAnnotation(annotationId),
        onFocusAnnotation: (annotationId) => handleFocusAnnotation(annotationId),
        onComment: (annotationId, text) => handleComment(annotationId, text),
        onRefresh: () => loadAnnotations(),
        onTabChange: (tab) => handleTabChange(tab),
        onLoadMore: () => loadMoreAnnotations()
      });
      var highlightPopup = new HighlightPopup(
        (id) => {
          return pageAnnotations.find((a) => String(a.id) === id);
        },
        (id, text) => handleComment(id, text)
      );
      var snipper = new Snipper(
        (area) => handleAreaSelected(area),
        () => sidebar.open()
        // Re-open sidebar on cancel
      );
      var isEnabled = false;
      function startHighlightSync() {
        stopHighlightSync();
        syncAttemptsLeft = 15;
        syncInterval = setInterval(() => syncHighlights(), 2e3);
      }
      function stopHighlightSync() {
        if (syncInterval) {
          clearInterval(syncInterval);
          syncInterval = null;
        }
        syncAttemptsLeft = 0;
      }
      async function syncHighlights() {
        syncAttemptsLeft--;
        if (syncAttemptsLeft <= 0) {
          stopHighlightSync();
        }
        if (suppressSync || pageAnnotations.length === 0) return;
        const missing = [];
        for (const annotation of pageAnnotations) {
          if (!annotation.id || !annotation.selectors) continue;
          if (annotation.type === "image") continue;
          const id = String(annotation.id);
          const highlights = highlightMap.get(id);
          if (!highlights || !highlights.some((h) => h.isConnected)) {
            if (highlights) highlightMap.delete(id);
            missing.push(annotation);
          }
        }
        if (missing.length === 0) {
          stopHighlightSync();
          return;
        }
        console.log(`[Scholic] Sync: ${missing.length} annotations missing highlights, re-anchoring...`);
        const anchored = await resolveAndRenderAnnotations(missing);
        if (anchored > 0) {
          await filterHighlights();
        }
      }
      async function bootstrap() {
        const domain = window.location.hostname;
        const result = await chrome.storage.local.get("enabledDomains");
        const enabledDomains = result.enabledDomains || {};
        const authResult = await chrome.storage.local.get("scholicToken");
        if (!authResult.scholicToken) {
          currentActiveTab = "all";
        }
        isEnabled = !!enabledDomains[domain];
        console.log(`[Scholic] Bootstrap: enabled=${isEnabled} for ${domain}`);
        if (isEnabled) {
          sidebar.showPeek();
          loadAnnotations();
          setupListeners();
          startHighlightSync();
        } else {
          sidebar.hideCompletely();
          clearStateAndHighlights();
          removeListeners();
          stopHighlightSync();
        }
      }
      function setupListeners() {
        document.addEventListener("mouseup", handleMouseUp);
        document.addEventListener("mousedown", handleMouseDown);
        document.addEventListener("keydown", handleKeyDown);
      }
      function removeListeners() {
        document.removeEventListener("mouseup", handleMouseUp);
        document.removeEventListener("mousedown", handleMouseDown);
        document.removeEventListener("keydown", handleKeyDown);
        popover.hide();
      }
      chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (message.type === "SET_ENABLED") {
          isEnabled = message.enabled;
          if (isEnabled) {
            sidebar.showPeek();
            loadAnnotations();
            setupListeners();
            startHighlightSync();
          } else {
            sidebar.hideCompletely();
            clearStateAndHighlights();
            removeListeners();
            stopHighlightSync();
            chrome.runtime.sendMessage({ type: "UPDATE_BADGE", data: { count: 0 } });
          }
          sendResponse({ ok: true });
        } else if (message.type === "TOGGLE_SIDEBAR") {
          if (isEnabled) {
            sidebar.toggle();
          } else {
          }
          sendResponse({ ok: true });
        }
        return true;
      });
      window.addEventListener("SCHOLIC_START_SCREENSHOT", () => {
        console.log("[Scholic] Screenshot mode started.");
        sidebar.hideCompletely();
        setTimeout(() => snipper.start(), 100);
      });
      async function handleAreaSelected(area) {
        console.log("[Scholic] Area selected:", area);
        try {
          const response = await chrome.runtime.sendMessage({ type: "CAPTURE_TAB" });
          if (!response?.dataUrl) throw new Error("Failed to capture tab");
          const croppedDataUrl = await cropImage(response.dataUrl, area);
          sidebar.openWithImage(croppedDataUrl);
        } catch (err) {
          console.error("[Scholic] Screenshot failed:", err);
          sidebar.open();
        }
      }
      function cropImage(dataUrl, area) {
        return new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => {
            const canvas = document.createElement("canvas");
            canvas.width = area.width;
            canvas.height = area.height;
            const ctx = canvas.getContext("2d");
            if (!ctx) {
              reject(new Error("Could not get canvas context"));
              return;
            }
            ctx.drawImage(
              img,
              area.x,
              area.y,
              area.width,
              area.height,
              // Source
              0,
              0,
              area.width,
              area.height
              // Destination
            );
            resolve(canvas.toDataURL("image/png"));
          };
          img.onerror = () => reject(new Error("Failed to load image for cropping"));
          img.src = dataUrl;
        });
      }
      function handleKeyDown(e) {
        if (!isEnabled) return;
        const target = e.target;
        if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable) return;
        if (e.altKey && e.key === "s") {
          e.preventDefault();
          sidebar.toggle();
        }
        if (e.altKey && e.key === "h") {
          e.preventDefault();
          const selection = window.getSelection();
          if (selection && !selection.isCollapsed && selection.toString().trim()) {
            try {
              const range = selection.getRangeAt(0);
              handleHighlight(range, selection.toString().trim());
              popover.hide();
            } catch {
            }
          }
        }
        if (e.key === "Escape") {
          popover.hide();
        }
      }
      function handleMouseUp(e) {
        if (!isEnabled) return;
        const target = e.target;
        if (target.closest("scholic-popover-host") || target.closest("scholic-sidebar-host")) {
          return;
        }
        setTimeout(() => {
          const selection = window.getSelection();
          if (!selection || selection.isCollapsed || !selection.toString().trim()) {
            popover.hide();
            return;
          }
          try {
            const range = selection.getRangeAt(0);
            popover.show(range);
          } catch {
            popover.hide();
          }
        }, 10);
      }
      function handleMouseDown(e) {
        const target = e.target;
        if (!target.closest("scholic-popover-host") && !target.closest("scholic-sidebar-host")) {
          popover.hide();
        }
      }
      function updateBadgeCount() {
        chrome.runtime.sendMessage({
          type: "UPDATE_BADGE",
          data: { count: pageAnnotations.length }
        });
      }
      function handleAnnotate(range, quoteText) {
        console.log("[Scholic] Annotate clicked. Quote:", quoteText);
        const selectors = describe(document.body, range);
        console.log("[Scholic] Generated selectors:", selectors);
        pendingHighlightElements = [];
        try {
          const highlightClone = range.cloneRange();
          pendingHighlightElements = highlightRange(highlightClone, "scholic-annotation-pending");
        } catch (e) {
          console.warn("[Scholic] Could not render pending highlight:", e);
        }
        window.getSelection()?.removeAllRanges();
        sidebar.openWithQuote(quoteText, selectors);
        console.log("[Scholic] Sidebar opened.");
      }
      function handleHighlight(range, quoteText) {
        const selectors = describe(document.body, range);
        pendingHighlightElements = [];
        try {
          const highlightClone = range.cloneRange();
          pendingHighlightElements = highlightRange(highlightClone, "scholic-private");
        } catch (e) {
          console.warn("[Scholic] Could not render highlight:", e);
        }
        window.getSelection()?.removeAllRanges();
        handleSaveAnnotation({
          url: window.location.href,
          quoteText,
          text: "",
          selectors,
          isPrivate: true
        });
      }
      async function handleSaveAnnotation(annotation) {
        console.log("[Scholic] Saving annotation...", annotation);
        const tempId = `__temp_${Date.now()}`;
        const tempAnnotation = {
          ...annotation,
          id: tempId,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          _isPending: true
        };
        pageAnnotations.unshift(tempAnnotation);
        const hasMore = annotationsOffset < annotationsTotal;
        await sidebar.renderAnnotationList(pageAnnotations, hasMore);
        try {
          const response = await chrome.runtime.sendMessage({
            type: "CREATE_ANNOTATION",
            data: annotation
          });
          console.log("[Scholic] Save response:", response);
          if (response?.annotation) {
            pageAnnotations = pageAnnotations.map(
              (a) => String(a.id) === tempId ? response.annotation : a
            );
            annotationsTotal = Math.max(annotationsTotal, pageAnnotations.filter((a) => !a._isPending).length);
            annotationsOffset = pageAnnotations.length;
            await sidebar.renderAnnotationList(pageAnnotations, annotationsOffset < annotationsTotal);
            const savedAnnotation = response.annotation;
            const annotationId = String(savedAnnotation.id);
            const cssClass = savedAnnotation.isPrivate ? "scholic-private" : "scholic-annotation";
            if (pendingHighlightElements.length > 0) {
              applyHighlightColor(pendingHighlightElements, savedAnnotation.highlightColor || "#A8D5B5");
              pendingHighlightElements.forEach((el) => {
                el.className = `scholic-highlight ${cssClass}`;
                el._scholicAnnotationId = annotationId;
                el.dataset.annotationId = annotationId;
                el.addEventListener("mouseenter", () => {
                  highlightPopup.show(annotationId, el);
                });
                el.addEventListener("mouseleave", () => {
                  highlightPopup.scheduleHide();
                });
              });
              highlightMap.set(String(annotationId), pendingHighlightElements);
              pendingHighlightElements = [];
            } else {
              removePendingHighlights();
              await resolveAndRenderAnnotations([savedAnnotation]);
            }
            updateBadgeCount();
          } else {
            pageAnnotations = pageAnnotations.filter((a) => String(a.id) !== tempId);
            await sidebar.renderAnnotationList(pageAnnotations, annotationsOffset < annotationsTotal);
          }
        } catch (err) {
          console.error("[Scholic] Failed to save annotation:", err);
          pageAnnotations = pageAnnotations.filter((a) => String(a.id) !== tempId);
          await sidebar.renderAnnotationList(pageAnnotations, annotationsOffset < annotationsTotal);
        }
      }
      async function handleDeleteAnnotation(annotationId) {
        const backup = pageAnnotations.find((a) => String(a.id) === String(annotationId));
        pageAnnotations = pageAnnotations.filter((a) => String(a.id) !== String(annotationId));
        annotationsTotal = Math.max(0, annotationsTotal - 1);
        annotationsOffset = Math.max(0, annotationsOffset - 1);
        const backupHighlights = highlightMap.get(annotationId);
        suppressSync = true;
        if (backupHighlights) {
          removeHighlights(backupHighlights);
          highlightMap.delete(annotationId);
        }
        suppressSync = false;
        await sidebar.renderAnnotationList(pageAnnotations, annotationsOffset < annotationsTotal);
        updateBadgeCount();
        try {
          await chrome.runtime.sendMessage({
            type: "DELETE_ANNOTATION",
            data: { id: annotationId }
          });
        } catch (err) {
          console.error("[Scholic] Failed to delete annotation:", err);
          if (backup) {
            pageAnnotations.push(backup);
            pageAnnotations.sort(
              (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
            );
            annotationsTotal += 1;
            annotationsOffset += 1;
            await sidebar.renderAnnotationList(pageAnnotations, annotationsOffset < annotationsTotal);
            await resolveAndRenderAnnotations([backup]);
            updateBadgeCount();
          }
        }
      }
      async function handleComment(annotationId, text) {
        try {
          const response = await chrome.runtime.sendMessage({
            type: "CREATE_COMMENT",
            data: { annotationId, text }
          });
          if (response?.comment) {
            pageAnnotations = pageAnnotations.map((a) => {
              if (String(a.id) === String(annotationId)) {
                return {
                  ...a,
                  comments: a.comments ? [...a.comments, response.comment] : [response.comment]
                };
              }
              return a;
            });
            await sidebar.renderAnnotationList(pageAnnotations, annotationsOffset < annotationsTotal);
            highlightPopup.refresh();
          }
        } catch (err) {
          console.error("[Scholic] Failed to post comment:", err);
        }
      }
      function handleFocusAnnotation(annotationId) {
        let highlights = highlightMap.get(annotationId) || [];
        if (highlights.length === 0) {
          highlights = getHighlightsForAnnotation(annotationId);
        }
        if (highlights.length > 0) {
          highlights[0].scrollIntoView({ behavior: "smooth", block: "center" });
          highlights.forEach((h) => {
            h.classList.add("scholic-highlight-focused");
            setTimeout(() => h.classList.remove("scholic-highlight-focused"), 1500);
          });
        }
      }
      function handleTabChange(tab) {
        currentActiveTab = tab;
        filterHighlights();
      }
      async function filterHighlights() {
        const result = await chrome.storage.local.get("scholicToken");
        const token = result.scholicToken;
        if (!token) {
          for (const annotation of pageAnnotations) {
            const highlights = highlightMap.get(String(annotation.id));
            if (highlights) {
              highlights.forEach((h) => h.classList.remove("scholic-hidden"));
            }
          }
          return;
        }
        const meResponse = await chrome.runtime.sendMessage({ type: "FETCH_ME" });
        const myUserId = meResponse?.id;
        if (myUserId === void 0) return;
        for (const annotation of pageAnnotations) {
          const highlights = highlightMap.get(String(annotation.id));
          if (!highlights) continue;
          const isMine = String(annotation.userId) === String(myUserId);
          let shouldShow = false;
          if (currentActiveTab === "all") {
            shouldShow = true;
          } else if (currentActiveTab === "mine") {
            shouldShow = isMine;
          } else if (currentActiveTab === "community") {
            shouldShow = !isMine;
          }
          highlights.forEach((h) => {
            if (shouldShow) {
              h.classList.remove("scholic-hidden");
            } else {
              h.classList.add("scholic-hidden");
            }
          });
        }
      }
      function onStorageChanged(changes, area) {
        if (area === "local" && changes.scholicToken) {
          if (changes.scholicToken.newValue) {
            console.log("[Scholic] Token detected, refreshing page state...");
            loadAnnotations();
          } else {
            console.log("[Scholic] Token removed, clearing state...");
            clearStateAndHighlights();
            sidebar.renderAnnotationList([], false);
          }
        }
      }
      chrome.storage.onChanged.addListener(onStorageChanged);
      function clearStateAndHighlights() {
        suppressSync = true;
        for (const highlights of highlightMap.values()) {
          removeHighlights(highlights);
        }
        highlightMap.clear();
        pageAnnotations = [];
        annotationsTotal = 0;
        annotationsOffset = 0;
        suppressSync = false;
        updateBadgeCount();
      }
      async function loadAnnotations() {
        try {
          clearStateAndHighlights();
          annotationsOffset = 0;
          annotationsTotal = 0;
          const response = await chrome.runtime.sendMessage({
            type: "FETCH_ANNOTATIONS",
            data: { url: window.location.href, limit: ANNOTATIONS_PAGE_SIZE, offset: 0 }
          });
          if (response?.annotations && Array.isArray(response.annotations)) {
            pageAnnotations = response.annotations;
            annotationsTotal = response.total ?? pageAnnotations.length;
            annotationsOffset = pageAnnotations.length;
            const hasMore = annotationsOffset < annotationsTotal;
            await sidebar.renderAnnotationList(pageAnnotations, hasMore);
            await resolveAndRenderAnnotations(pageAnnotations);
            await filterHighlights();
            updateBadgeCount();
          } else {
            await sidebar.renderAnnotationList([]);
            updateBadgeCount();
          }
        } catch (err) {
          console.error("[Scholic] Failed to load annotations:", err);
        }
      }
      async function loadMoreAnnotations() {
        if (annotationsOffset >= annotationsTotal) return;
        try {
          const response = await chrome.runtime.sendMessage({
            type: "FETCH_ANNOTATIONS",
            data: { url: window.location.href, limit: ANNOTATIONS_PAGE_SIZE, offset: annotationsOffset }
          });
          if (response?.annotations && Array.isArray(response.annotations)) {
            const newAnnotations = response.annotations;
            pageAnnotations = [...pageAnnotations, ...newAnnotations];
            annotationsTotal = response.total ?? annotationsTotal;
            annotationsOffset = pageAnnotations.length;
            const hasMore = annotationsOffset < annotationsTotal;
            await sidebar.renderAnnotationList(pageAnnotations, hasMore);
            await resolveAndRenderAnnotations(newAnnotations);
            await filterHighlights();
            updateBadgeCount();
          }
        } catch (err) {
          console.error("[Scholic] Failed to load more annotations:", err);
        }
      }
      async function resolveAndRenderAnnotations(annotations) {
        let count = 0;
        suppressSync = true;
        for (const annotation of annotations) {
          if (!annotation.selectors || !annotation.id) continue;
          if (annotation.type === "image") continue;
          const annotationId = String(annotation.id);
          try {
            const range = await anchor(document.body, annotation.selectors);
            console.log(`[Scholic] Anchored ${annotationId}: "${range.toString().slice(0, 50)}..."`);
            const cssClass = annotation.isPrivate ? "scholic-private" : "scholic-annotation";
            const highlights = highlightRange(range, cssClass, annotationId);
            if (highlights.length === 0) {
              console.warn(`[Scholic] Anchored ${annotationId} but highlightRange returned 0 elements`);
              continue;
            }
            const defaultColor = annotation.isPrivate ? "#E8C547" : "#A8D5B5";
            applyHighlightColor(highlights, annotation.highlightColor || defaultColor);
            highlightMap.set(annotationId, highlights);
            highlights.forEach((el) => {
              el.addEventListener("mouseenter", () => {
                highlightPopup.show(annotationId, el);
              });
              el.addEventListener("mouseleave", () => {
                highlightPopup.scheduleHide();
              });
            });
            count++;
          } catch (err) {
            console.warn(`[Scholic] Failed to anchor ${annotationId}:`, err);
          }
        }
        suppressSync = false;
        return count;
      }
      function removePendingHighlights() {
        const pending = document.querySelectorAll(
          "scholic-highlight.scholic-annotation-pending"
        );
        const parentsToNormalize = /* @__PURE__ */ new Set();
        pending.forEach((el) => {
          const parent = el.parentNode;
          if (parent) {
            const children = Array.from(el.childNodes);
            children.forEach((child) => parent.insertBefore(child, el));
            parent.removeChild(el);
            parentsToNormalize.add(parent);
          }
        });
        parentsToNormalize.forEach((parent) => parent.normalize());
      }
      if (!IS_IFRAME) {
        if (document.readyState === "loading") {
          document.addEventListener("DOMContentLoaded", () => bootstrap());
        } else {
          bootstrap();
        }
        console.log("[Scholic] Content script loaded.");
      }
    }
  });
  require_content();
})();
//# sourceMappingURL=content.js.map
